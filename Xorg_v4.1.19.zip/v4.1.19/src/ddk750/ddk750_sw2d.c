/*******************************************************************
* 
*         Copyright (c) 2007 by Silicon Motion, Inc. (SMI)
* 
*  All rights are reserved. Reproduction or in part is prohibited
*  without the written consent of the copyright owner.
* 
*  sw2d.c --- SMI DDK 
*  This file contains the source code for the software 2D engine
*  implementation.
* 
*******************************************************************/
//#include "ddk750_hardware.h"
#include "ddk750_sw2d.h"

#define min(a,b)    (((a) < (b)) ? (a) : (b))
#define max(a,b)    (((a) > (b)) ? (a) : (b))

unsigned long swRasterOp2(unsigned long S, unsigned long D, unsigned long rop2)
{
    unsigned long opValue;
	//xf86Msg(X_INFO, "dddddddddddddd, color=[%x],destColor16=[%x], rop2=[%x]", S,D, rop2 );

    switch (rop2)
    {
    case 0:
    opValue = 0;
    break;
    case 1:
    opValue = ~(S | D);
    break;
    case 2:
    opValue = ~S & D;
    break;
    case 3:
    opValue = ~S;
    break;
    case 4:
    opValue = S & ~D;
    break;
    case 5:
    opValue = ~D;
    break;
    case 6:
    opValue = S ^ D;
    break;
    case 7:
    opValue = ~(S & D);
    break;
    case 8:
    opValue = S & D;
    break;
    case 9:
    opValue = ~ (S ^ D);
    break;
    case 0xA:
    opValue = D;
    break;
    case 0xB:
    opValue = ~S | D;
    break;
    case 0xC:
    opValue = S;
    break;
    case 0xD:
    opValue = S | ~D;
    break;
    case 0xE:
    opValue = S | D;
    break;
    case 0xF:
    opValue = 0xFFFFFFFF;
    break;
    default:
        opValue = S;
        break;
    }
	//xf86Msg(X_INFO, "dddddddddddddd, opv=[%x],destColor16=[%x], rop2=[%x]", opValue );

    return(opValue);
}

#if 0
/*
 * This function set up a pixel value in the frame buffer.
 *
 * Note:
 * 1) It can only set pixel within the frame buffer.
 * 2) This function is NOT for drawing surface created in system memory.
 *
 */
void swSetPixel(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x, 
unsigned long y,        /* Position (X, Y) to set in pixel value */
unsigned long color,    /* Color */
unsigned long rop2)     /* ROP value */
{
    unsigned long destAddr;
    unsigned char  destColor8;
    unsigned short destColor16;
    unsigned long  destColor32;

    destAddr = (y * pitch) + (x * bpp/8) + destBase;

    switch (bpp)
    {
        case 8:
            destColor8 = peekByte(destAddr);
            destColor8 = (unsigned char)swRasterOp2(color, destColor8, rop2);
            pokeByte(destAddr, destColor8);
            break;

        case 16:
            destColor16 = peekWord(destAddr);
            destColor16 = (unsigned short)swRasterOp2(color, destColor16, rop2);
            pokeWord(destAddr, destColor16);
            break;

        case 32:
        default:
            destColor32 = peekDWord(destAddr);
            destColor32 = (unsigned long)swRasterOp2(color, destColor32, rop2);
            pokeDWord(destAddr, destColor32);
            break;
    }
}


/*
 * This function gets a pixel value in the frame buffer.
 *
 * Note:
 * 1) It can only get pixel within the frame buffer.
 * 2) This function is NOT for drawing surface created in system memory.
 * 3) This function always return a 32 bit pixel value disregard bpp = 8, 16, or 32.
 *    The calling funtion has to type cast the return value into Byte, word or 
 *    DWord according to BPP.
 *
 */
unsigned long swGetPixel(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x, 
unsigned long y)        /* Position (X, Y) to set in pixel value */
{
    unsigned long destAddr;
    unsigned long pixel = 0;

    destAddr = (y * pitch) + (x * bpp/8) + destBase;
    
    switch (bpp)
    {
        case 8:
            pixel = (unsigned long) peekByte(destAddr);
            break;

        case 16:
            pixel = (unsigned long) peekWord(destAddr);
            break;

        case 32:
        default:
            pixel = (unsigned long) peekDWord(destAddr);
            break;
    }

    return(pixel);
}
#endif

/*
 *  This function uses software only method to fill a rectangular area with a specific color.
 * Input: See comment of code below.
 * 
 */
void swRectFill(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x,
unsigned long y,        /* Upper left corner (X, Y) of rectangle in pixel value */
unsigned long width, 
unsigned long height,   /* width and height of rectange in pixel value */
unsigned long color,    /* Fill color */
unsigned long rop2)     /* ROP value */
{
    unsigned long dx, dy;

    for (dy=y; dy<(y+height); dy++)
        for (dx=x; dx<(x+width); dx++)
            swSetPixel(destBase, pitch, bpp, dx, dy, color, rop2);
}


/*
 * This function draws a hollow rectangle, no fills.
 */
void swRect(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x,
unsigned long y,        /* Upper left corner (X, Y) of rectangle in pixel value */
unsigned long width, 
unsigned long height,   /* width and height of rectange in pixel value */
unsigned long color,    /* border color */
unsigned long rop2)     /* ROP value */
{
    swRectFill(destBase, pitch, bpp, x,                 y,  width,      1, color, rop2);
    swRectFill(destBase, pitch, bpp, x,        y+height-1,  width,      1, color, rop2);
    swRectFill(destBase, pitch, bpp, x,                 y,      1, height, color, rop2);
    swRectFill(destBase, pitch, bpp, x+width-1,         y,      1, height, color, rop2);
}


void swHorizontalLine(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x,
unsigned long y,        /* Starting point (X, Y) of line */
unsigned long length,   /* Length of line */
unsigned long color,    /* Color */
unsigned long rop2)     /* ROP value */
{
    swRectFill(destBase, pitch, bpp, x, y, length, 1, color, rop2);
}


void swVerticalLine(
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x,
unsigned long y,        /* Starting point (X, Y) of line */
unsigned long length,   /* Length of line */
unsigned long color,    /* Color */
unsigned long rop2)     /* ROP value */
{
    swRectFill(destBase, pitch, bpp, x, y, 1, length, color, rop2);
}

/* 
 * Function to draw a line.
 */
long swLine(
    unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
    unsigned long pitch,    /* Pitch value of destination surface in BYTES */
    unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
    unsigned long x0,       /* Starting X Coordinate */
    unsigned long y0,       /* Starting Y Coordinate */
    unsigned long x1,       /* Ending X Coordinate */
    unsigned long y1,       /* Ending Y Coordinate */
    unsigned long color,    /* Color of the line */
    unsigned long rop2      /* ROP value */
)
{
    unsigned long dx, dy, x, y, xEnd, yEnd;
    long et, k1, k2;

    /* Calculate delta X */
    if (x0 <= x1)
        dx = x1 - x0;
    else
        dx = x0 - x1;

    /* Calculate delta Y */
    if (y0 <= y1)
        dy = y1 - y0;
    else
        dy = y0 - y1;

    et = 2 * min(dy, dx) - max(dy, dx);
    k1 = 2 * min(dy, dx);
    k2 = 2 * (min(dy, dx) - max(dy, dx));

    if (dx >= dy)
    {
        /* 
         * Major Axis X 
         */

        if (x0 > x1)
        {
            /* x step is negative */
            x = x1;
            y = y1;
            xEnd = x0;
            yEnd = y0;
        }
        else
        {
            /* x step is positive */
            x = x0;
            y = y0;
            xEnd = x1;
            yEnd = y1;
        }

        /* Set the first pixel */
        swSetPixel(destBase, pitch, bpp, x, y, color, rop2);

        while (x < xEnd)
        {
            x++;
            if (et < 0)
                et += k1;
            else
            {
                if (y < yEnd)
                    y++;
                else
                    y--;
                et += k2;
            }

            swSetPixel(destBase, pitch, bpp, x, y, color, rop2);
        }
    }
    else
    {
        /* 
         * Major Axis Y 
         */

        if (y0 > y1)
        {
            /* y step is negative */
            x = x1;
            y = y1;
            xEnd = x0;
            yEnd = y0;
        }
        else
        {
            /* x step is positive */
            x = x0;
            y = y0;
            xEnd = x1;
            yEnd = y1;
        }

        /* Set the first pixel */
        swSetPixel(destBase, pitch, bpp, x, y, color, rop2);

        while (y < yEnd)
        {
            y++;
            if (et < 0)
                et += k1;
            else
            {
                if (x < xEnd)
                    x++;
                else
                    x--;
                et += k2;
            }

            swSetPixel(destBase, pitch, bpp, x, y, color, rop2);
        }
    }

    return 0;
}


/*
 * Video Memory to Video Memroy data transfer.
 *
 * Note: 
 * 1) All addresses are offset from the beginning for frame buffer.
 * 2) Both source and destination have to be same bpp (color depth).
 * 
 */
void swVideoMem2VideoMemBlt(
unsigned long sBase,  /* Address of source: offset in frame buffer */
unsigned long sPitch, /* Pitch value of source surface in BYTE */
unsigned long sx,
unsigned long sy,     /* Starting coordinate of source surface */
unsigned long dBase,  /* Address of destination: offset in frame buffer */
unsigned long dPitch, /* Pitch value of destination surface in BYTE */
unsigned long bpp,   /* color depth of destiination, source must have same bpp */
unsigned long dx,
unsigned long dy,     /* Starting coordinate of destination surface */
unsigned long width, 
unsigned long height, /* width and height of rectange in pixel value */
unsigned long rop2)   /* ROP value */
{
    unsigned long color, nDirection;
    long x, y, opSign;

    nDirection = LEFT_TO_RIGHT;
    opSign = 1;

    /* If source and destination are the same surface, need to check for overlay cases */
    if (sBase == dBase && sPitch == dPitch)
    {
        /* Determine direction of operation */
        if (sy < dy)
        {
            /* +----------+
               |S         |
               |   +----------+
               |   |      |   |
               |   |      |   |
               +---|------+   |
                   |         D|
                   +----------+ */
    
            nDirection = BOTTOM_TO_TOP;
        }
        else if (sy > dy)
        {
            /* +----------+
               |D         |
               |   +----------+
               |   |      |   |
               |   |      |   |
               +---|------+   |
                   |         S|
                   +----------+ */
    
            nDirection = TOP_TO_BOTTOM;
        }
        else
        {
            /* sy == dy */
    
            if (sx <= dx)
            {
                /* +------+---+------+
                   |S     |   |     D|
                   |      |   |      |
                   |      |   |      |
                   |      |   |      |
                   +------+---+------+ */
    
                nDirection = RIGHT_TO_LEFT;
            }
            else
            {
                /* sx > dx */
    
                /* +------+---+------+
                   |D     |   |     S|
                   |      |   |      |
                   |      |   |      |
                   |      |   |      |
                   +------+---+------+ */
    
                nDirection = LEFT_TO_RIGHT;
            }
        }
    }
    
    if ((nDirection == BOTTOM_TO_TOP) || (nDirection == RIGHT_TO_LEFT))
    {
        sx += width - 1;
        sy += height - 1;
        dx += width - 1;
        dy += height - 1;
        opSign = (-1);
    }

    for (y=0; y<height; y++)
    {
        for (x=0; x<width; x++)
        {
            color = swGetPixel(sBase, sPitch, bpp, sx+(opSign*x), sy+(opSign*y));
            swSetPixel(dBase, dPitch, bpp, dx+(opSign*x), dy+(opSign*y), color, rop2);
        }
    }
}
