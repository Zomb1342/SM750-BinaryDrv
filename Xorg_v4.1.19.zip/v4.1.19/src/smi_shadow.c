/*******************************************************************
 
Copyright (c) 2012 by Silicon Motion, Inc. (SMI)

Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights to 
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies 
of the Software, and to permit persons to whom the Software is furnished to 
do so, subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT.  IN NO EVENT SHALL MILL CHEN, MONK LIU, ALEX YAO, 
SUNNY YANG, ILENA ZHOU, MANDY WANG OR COPYRIGHT 
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
OTHER DEALINGS IN THE SOFTWARE.
 
*******************************************************************/


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "smi_common.h"
#include "shadowfb.h"
#include "servermd.h"

void SMI_RefreshArea(ScrnInfoPtr pScrn, int num, BoxPtr pbox)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    int width, height, Bpp, FBPitch;
    unsigned char *src, *dst;

    Bpp = pScrn->bitsPerPixel >> 3;
    FBPitch = BitmapBytePad(pScrn->displayWidth * pScrn->bitsPerPixel);

    while(num--)
    {
        width = (pbox->x2 - pbox->x1) * Bpp;
        height = pbox->y2 - pbox->y1;
        src = pSmi->ShadowPtr + (pbox->y1 * pSmi->ShadowPitch) + 
                        (pbox->x1 * Bpp);
        dst = pSmi->pFB + (pbox->y1 * FBPitch) + (pbox->x1 * Bpp);

        while(height--)
        {
            memcpy(dst, src, width);
            dst += FBPitch;
            src += pSmi->ShadowPitch;
        }

        pbox++;
    }
}

void SMI_RefreshAreaInverted32(ScrnInfoPtr pScrn, int num, BoxPtr pbox)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    int width, height, srcPitch, dstPitch, count;
    CARD32 *dstPtr, *srcPtr, *src, *dst;

    dstPitch = pScrn->displayWidth;
    srcPitch = pSmi->ShadowPitch >> 2;

    while(num--)
    {
        width = pbox->x2 - pbox->x1;
        height = pbox->y2 - pbox->y1;
        srcPtr = (CARD32 *)pSmi->ShadowPtr + (pbox->y1 * srcPitch) + pbox->x1;
        dstPtr = (CARD32 *)pSmi->pFB + ((pScrn->virtualY - pbox->y1) * srcPitch) + 
                (pScrn->virtualX - pbox->x1);

        while(height--)
        {
            src = srcPtr;
            dst = dstPtr;
            count = width;
            while(count--)
            {
                *(dst--) = *(src++);
            }
            dstPtr -= dstPitch;
            srcPtr += srcPitch;
        }

        pbox++;
    }
}

void SMI_RefreshAreaInverted16(ScrnInfoPtr pScrn, int num, BoxPtr pbox)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    int width, height, srcPitch, dstPitch, count;
    CARD16 *dstPtr, *srcPtr, *src, *dst;

    dstPitch = pScrn->displayWidth;
    srcPitch = pSmi->ShadowPitch >> 1;

    while(num--)
    {
        width = pbox->x2 - pbox->x1;
        height = pbox->y2 - pbox->y1;
        srcPtr = (CARD16 *)pSmi->ShadowPtr + (pbox->y1 * srcPitch) + pbox->x1;
        dstPtr = (CARD16 *)pSmi->pFB + ((pScrn->virtualY - pbox->y1) * dstPitch) + 
                (pScrn->virtualX - pbox->x1);

        while(height--)
        {
            src = srcPtr;
            dst = dstPtr;
            count = width;
            while(count--)
            {
                *(dst--) = *(src++);
            }
            dstPtr -= dstPitch;
            srcPtr += srcPitch;
        }

        pbox++;
    }
}


void SMI_RefreshArea16(ScrnInfoPtr pScrn, int num, BoxPtr pbox)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    int count, width, height, y1, y2, dstPitch, srcPitch;
    CARD16 *dstPtr, *srcPtr, *src;
    CARD32 *dst;

    if (pSmi->RotateAngle == 0)
    {
        SMI_RefreshArea(pScrn, num, pbox);
        return;
    }
    else if (pSmi->RotateAngle == 180)
    {
        SMI_RefreshAreaInverted16(pScrn, num, pbox);
        return;
    }

    dstPitch = pScrn->displayWidth;
    if (pSmi->RotateAngle == 90)
        srcPitch = pSmi->ShadowPitch >> 1;
    else
        srcPitch = (-1) * pSmi->ShadowPitch >> 1;
    
    while(num--)
    {
        width = pbox->x2 - pbox->x1;
        y1 = pbox->y1 & ~1;
        y2 = (pbox->y2 + 1) & ~1;
        height = (y2 - y1) >> 1;

        if (pSmi->RotateAngle == 270)
        {
            dstPtr = (CARD16*)pSmi->pFB +
                (pbox->x1 * dstPitch) + pScrn->virtualX - y2;
            srcPtr = (CARD16*)pSmi->ShadowPtr +
                ((1 - y2) * srcPitch) + pbox->x1;
        }
        else
        {
            dstPtr = (CARD16*)pSmi->pFB +
                ((pScrn->virtualY - pbox->x2) * dstPitch) + y1;
            srcPtr = (CARD16*)pSmi->ShadowPtr +
                (y1 * srcPitch) + pbox->x2 - 1;
        }

        while(width--)
        {
            src = srcPtr;
            dst = (CARD32*)dstPtr;
            count = height;
            while(count--)
            {
                *(dst++) = src[0] | src[srcPitch] << 16;
                src += srcPitch * 2;
            }
            srcPtr += pSmi->RotateAngle == 90 ? -1 : 1;
            dstPtr += dstPitch;
        }

        pbox++;
    }
}

void SMI_RefreshArea32(ScrnInfoPtr pScrn,int num,BoxPtr pbox)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    int count, width, height, dstPitch, srcPitch;
    CARD32 *dstPtr, *srcPtr, *src, *dst;

    if (pSmi->RotateAngle == 0)
    {
        SMI_RefreshArea(pScrn, num, pbox);
        return;
    }
    else if (pSmi->RotateAngle == 180)
    {
        SMI_RefreshAreaInverted32(pScrn, num, pbox);
        return;
    }

    dstPitch = pScrn->displayWidth;
    if (pSmi->RotateAngle == 90)
        srcPitch = pSmi->ShadowPitch >> 2;
    else
        srcPitch = (-1) * pSmi->ShadowPitch >> 2;
    
    while(num--)
    {
        width = pbox->x2 - pbox->x1;
        height = pbox->y2 - pbox->y1;

        if (pSmi->RotateAngle == 270)
        {
            dstPtr = (CARD32*)pSmi->pFB +
                (pbox->x1 * dstPitch) + pScrn->virtualX - pbox->y2;
            srcPtr = (CARD32*)pSmi->ShadowPtr +
                ((1 - pbox->y2) * srcPitch) + pbox->x1;
        }
        else
        {
            dstPtr = (CARD32*)pSmi->pFB +
                ((pScrn->virtualY - pbox->x2) * dstPitch) + pbox->y1;
            srcPtr = (CARD32*)pSmi->ShadowPtr +
                (pbox->y1 * srcPitch) + pbox->x2 - 1;
        }

        while(width--)
        {
            src = srcPtr;
            dst = dstPtr;
            count = height;
            while(count--)
            {
                *(dst++) = *src;
                src += srcPitch;
            }
            srcPtr += pSmi->RotateAngle == 90 ? -1 : 1;
            dstPtr += dstPitch;
        }

        pbox++;
    }
}
