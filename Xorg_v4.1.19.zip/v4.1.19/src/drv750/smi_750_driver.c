/*******************************************************************
 
Copyright (c) 2012 by Silicon Motion, Inc. (SMI)

Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights to 
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies 
of the Software, and to permit persons to whom the Software is furnished to 
do so, subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT.  IN NO EVENT SHALL MILL CHEN, MONK LIU, ALEX YAO, 
SUNNY YANG, ILENA ZHOU, MANDY WANG OR COPYRIGHT 
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR 
OTHER DEALINGS IN THE SOFTWARE.
 
*******************************************************************/
#include	"../smi_common.h"
#include 	"../smi_driver.h"
#include   "../smi_video.h"
#include	"smi_750_driver.h"
#include 	"smi_750_hw.h"
#include	"../smi_dbg.h"
#include    "ddk750/ddk750_reg.h"
#if (SMI_RANDR && RANDR_12_INTERFACE)
#include    "smi_crtc.h"
#endif
#if USE_VBE
#include 	"vbe.h"
#include    "vbeModes.h"
#endif
#include    "HDMI_swi2c.h"
#include    "siHdmiTx_902x_TPI.h"


pll_value_t *pll_table;


void (*pfn_I2CPutBits_750[])(I2CBusPtr,int,int)=
{NULL,NULL};

void (*pfn_I2CGetBits_750[])(I2CBusPtr,int*,int*)=
{NULL,NULL};

/*-----------------------------------------------------------------------------
 *  they are just static datas,don't pass their address to X
 *  you can put down the member data you want into these const
 *  variable and make a copy of them to use in driver
 *  or dualview and multicard case will shut your driver off
 *
 *-----------------------------------------------------------------------------*/
static const SMI750HWRec sm750_hwrec = {
	.base = {
		.pcDeepMap = sm750_pcDeepmap,/* actually,NULL value can be just ignored,gcc will know it*/
		.pcEntityInit = sm750_entityInit,
		.pcEntityEnter = sm750_entityEnter,
		.pcEntityLeave = sm750_entityLeave,	
		.pcCloseAllScreen = sm750_closeAllScreen,
		.pcFBSize = sm750_totalFB,
		.pcInitHardware = NULL,
		.pcVideoReset = sm750_VideoReset,
	},

};


static const SMI750Rec sm750_rec = {
	.base = {
		.minHeight = 128,
		.psGetMapResult = sm750_getMapResult,
		.psVgaPciInit = sm750_vgaAndpciInit,
		.psHandleOptions = sm750_handleOptions,
		.psValidMode = sm750_validMode,
		.psSetMode = sm750_setMode,
		.psAdjustFrame = sm750_adjustFrame,
		.psLoadPalette = sm750_loadPalette,
		.psSetDisplay = sm750_setDisplay,
		.psSaveText = sm750_saveText,
#if (SMI_RANDR && RANDR_12_INTERFACE)
		.psCrtcPreInit = SMI750_CrtcPreInit,
		.psOutputPreInit = SMI750_OutputPreInit,
		.psI2CInit = sm750_I2CInit,
#endif
	},
};

int hdmi_sii9022A_enable(SMIPtr pSmi)
{
    int rc;
    unsigned char rcc;
    int retries = 10;
    int count;
    struct i2c_client *client=0UL;
	ENTER();
    HDMI_swI2CInit( pSmi->i2c_HDMI_ClockGPIO, pSmi->i2c_HDMI_DataGPIO);
    LEAVE(0);

}

int hdmi_sii_probe()
{
	int ret=0;
	ENTER();
	//
	// Initialize the registers as required. Setup firmware vars.
	//
	siHdmiTx_VideoSel( HDMI_720P60 );
	siHdmiTx_AudioSel( AFS_48K);
	siHdmiTx_TPI_Init();
    siHdmiTx_VideoSet();
	//msleep(5000);

	LEAVE(ret);

}

void sm750_InitHDMIChip(SMIPtr pSmi)
{
	ENTER();
	hdmi_sii9022A_enable(pSmi);
    hdmi_sii_probe();
    LEAVE();
}

void sm750_InitDVIChip()
{
#ifdef USE_DVICHIP
    ddk750_initDVIDisp();
#endif
}

void SMI750_DisplayPowerManagementSet(ScrnInfoPtr pScrn,
                                 int PowerManagementMode, int flags)
{
    ENTER();
    SMIPtr              pSmi = SMIPTR(pScrn);

    if (pSmi->CurrentDPMS != PowerManagementMode) {
        switch (PowerManagementMode)
        {
           case DPMSModeOn:
                ddk750_setDPMS(SMI_DPMS_ON);
                break;
           case DPMSModeStandby:
                ddk750_setDPMS(SMI_DPMS_STANDBY);
                break;
           case DPMSModeSuspend:
                ddk750_setDPMS(SMI_DPMS_SUSPEND);
                break;
           case DPMSModeOff:
                ddk750_setDPMS(SMI_DPMS_OFF);
                break;
         }

#if (SMI_RANDR && RANDR_12_INTERFACE)
        /* Set the DPMS mode to every output and CRTC */
        xf86DPMSSet(pScrn, PowerManagementMode, flags);
#endif
        /* Save the current power state */
        pSmi->CurrentDPMS = PowerManagementMode;
    }
     LEAVE();
}



/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_genSMI
 *  Description:  build up the entire private date for sm750 video card and initialize them.
 *	malloc an SMIPtr (named pSmi) and SMIHWPtr(named pHw) if in need
 *  setting confirmed member of pSmi and pHw (such as physical address,etc..)
 *  hook all known function pointer to pSmi and pHw
 *  in a sentence, put everything associated with SM750 this stage can confirm into the two structure !!!
 * =====================================================================================
 */
SMIPtr sm750_genSMI(pointer priv,int entityIndex)
{
	SMIPtr pSmi;
#ifdef XSERVER_LIBPCIACCESS
	struct pci_device * pPci;
#else
	pciVideoPtr pPci;
#endif

	ENTER();
	/*what's the difference between 'pScrn->entityList[0]' and 'pEntInfo->index'??*/
	pPci = xf86GetPciInfoForEntity(entityIndex);
	/* pSmi always need create for every screen*/
	pSmi = (SMIPtr)XNFcalloc(sizeof(SMI750Rec));	
	memset(pSmi,0, sizeof(SMI750Rec));
	if(pSmi == NULL)
		return pSmi;
	memcpy(pSmi,&sm750_rec,sizeof(SMI750Rec));
#if ((SMI_RANDR && USE_VBE) && !RANDR_12_INTERFACE)
    pSmi->psSetMode= sm750_setModeVBE;
#endif
	/*This function is associated with screen
	, but maybe two screen belongs to one entity (dualview)*/
	pSmi->pHardware = priv;

	/* if priv is NULL,means we need create a pHw
	 * below code can handle 2 screen per entity case
	 * but not work for 3+ screen per entity cases
	 * */
	if(!pSmi->pHardware)
	{
		/*
		 * Allocate an 'Chip'Rec, and hook it into pScrn->driverPrivate.
		 * pScrn->driverPrivate is initialised to NULL, so we can check if
		 * the allocation has already been done.
		 */
		SMI750HWPtr p750Hw;
		p750Hw = pSmi->pHardware = (SMIHWPtr)XNFcalloc(sizeof(SMI750HWRec));
		if(pSmi->pHardware == NULL)
			LEAVE(NULL);
		memcpy(pSmi->pHardware,&sm750_hwrec,sizeof(SMI750HWRec));
		p750Hw->pRegSave = xnfcalloc(sizeof(SMI750RegRec),1);
		if(p750Hw->pRegSave == NULL)
			LEAVE(NULL);
		p750Hw->fonts = xalloc(KB(64));
		if(p750Hw->fonts == NULL)
			LEAVE(NULL);
		
		pSmi->pHardware->dual = 1;
		pSmi->pHardware->primary_screen_rec = pSmi;
		pSmi->screen = 0;
		
		/* Put what you already known into structure */
	#ifdef XSERVER_LIBPCIACCESS
		pSmi->pHardware->phyaddr_reg = pPci->regions[1].base_addr;
		pSmi->pHardware->physize_reg = 0x200000;
		pSmi->pHardware->phyaddr_mem = pPci->regions[0].base_addr;
		/*Get total video memory size from misc ccontrol register MMIO_base+0x0004 bit13 and bit12
		pSmi->pHardware->physize_mem = get_total_fb()*/;
		pSmi->pHardware->devId = pPci->device_id;
	#else
		pSmi->pHardware->phyaddr_reg = pPci->memBase[1];
		pSmi->pHardware->physize_reg = 0x200000;
		pSmi->pHardware->phyaddr_mem = pPci->memBase[0];
		/*Get total video memory size from misc ccontrol register MMIO_base+0x0004 bit13 and bit12
		pSmi->pHardware->physize_mem = get_total_fb()*/;
		pSmi->pHardware->devId = pPci->chipType;
	#endif
	
	#ifdef XSERVER_LIBPCIACCESS
		pSmi->pHardware->revId = pPci->revision;
		pSmi->pHardware->pPci = pPci;
	#else
	    pSmi->pHardware->revId = pPci->chipRev; //ilena guess...
	    pSmi->pHardware->pPci = pPci;
	#endif
	}else{
		/*
		 * pSmi->pHardware is not NULL, which means current entity already
		 * mallocated a SMIHWPtr structure,so we are in dualview 
		 * mode!
		 * */
		pSmi->pHardware->dual += 1;/*The total number of screen*/
		pSmi->screen = (pSmi->pHardware->dual)-1;/*The index of screen*/
	}
	
	/*Assign the private function for SM750*/

	LEAVE(pSmi);
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_pcDeepmap
 *  Description:  
 * =====================================================================================
 */
void sm750_pcDeepmap(SMIHWPtr pHw)
{
	ENTER();	
	SMI750HWPtr p750Hw = (SMI750HWPtr)pHw;
	SMIPtr pSmi = HWPSMI(pHw);
	ScrnInfoPtr pScrn = SMIPSI(pSmi);

            pHw->DPRBase = pHw->pReg + 0x100000;
            pHw->VPRBase = pHw->pReg + 0x000000;
            pHw->CPRBase = pHw->pReg + 0x090000;
            pHw->DCRBase = pHw->pReg + 0x080000;
            pHw->SCRBase = pHw->pReg + 0x000000;
            pHw->IOBase = 0;
            pHw->DataPortBase = pHw->pReg + 0x110000;
            pHw->DataPortSize = 0x10000;
	LEAVE(TRUE);
}

void sm750_vgaAndpciInit(ScrnInfoPtr pScrn,int entityIndex)
{
	ENTER();
#ifdef 	XSERVER_LIBPCIACCESS	
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,7,0,0,0)		
	struct pci_device * pd;
	pd = xf86GetPciInfoForEntity(entityIndex);	
	if(pd && !xf86IsEntityPrimary(entityIndex)){
		/* give up vga legency resource decodes for none-primary vga cards 			  
		   Note: pci_device_vgaarb_*** function start be exist since libpciaccess v0.11.0 (ubuntu10.04). for v0.10.* and below (ubuntu9.10),
		   these function will throw you error when startx (but no error occured in compiling)
		/* I cannot get libpciaccess version number, so use X server version is a work around */
		pci_device_vgaarb_set_target(pd);
		pci_device_vgaarb_decodes(0);
		/*	monk:
			Weird, with only above line, it not work.
			it works well together with below line.
			root cause:

			Libpciaccess will not use new decode flag passing to its immediate kernel sys call 
			but use original decode flag, and save new decode flag to its struct member after kernel sys call.
			That's make kernel not sync with the latest request .Maybe it's a bug of libpciaccess
			So I used a tricky method to fool around the libpciacess in order to make kernel vgaarb 
			consider this card already disclaimed for its vga legency resource decodings:

			Call again "pci_device_vgaarb_decodes" with meaningless  decode flag but not the same as last one
			it will make libpciaccess using last saved decode flag (it is 0) as the parameter for kernel  sys call
		 */
		pci_device_vgaarb_decodes(0x10);		
	}else{
		xf86ErrorF("This should never happen!\n");
		LEAVE();
	}
#endif
#endif	
	
#ifdef  XSERVER_LIBPCIACCESS
	/*Enable pci device will open pci config space io/mem bits in theory ( according to kernel source code: pci-sysfs.c )
	Butter... seems 718 and 750 only be enabled for mem bits
	*/
	pci_device_enable(pd);
#else
	/* TODO: how to enable pci device with out libpciaccess ? */
#endif
	LEAVE();
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_entityInit
 *  Description:  init hardware
 * =====================================================================================
 */
void sm750_entityInit(int entIndex,pointer private)
{
    initchip_param_t initParam;
	SMIHWPtr pHw = (SMIHWPtr)private;
	unsigned int ulReg;
	
	ENTER();

    initParam.powerMode = 0;  /* Default to power mode 0 */
	initParam.chipClock = DEFAULT_MEMORY_CLK;
    initParam.memClock = DEFAULT_MEMORY_CLK; /* Default memory clock to 144MHz */
    initParam.masterClock = initParam.chipClock/3; /* Default master clock to half of mem clock */
    initParam.setAllEngOff = 0; /* Using 2D now*/
	initParam.resetMemory = 1;
	
	ddk750_set_mmio(pHw->pReg,pHw->devId,0);
    ddk750_initHw(&initParam);
	
	/* Disable LCD hardware cursor, if a former application left it on */
	ulReg = PEEK32(PANEL_HWC_ADDRESS);
	ulReg = FIELD_SET(ulReg, PANEL_HWC_ADDRESS, ENABLE, DISABLE); 
	POKE32(PANEL_HWC_ADDRESS, ulReg);
	
	/* Disable CRT hardware cursor, if a former application left it on */
	ulReg = PEEK32(CRT_HWC_ADDRESS);
	ulReg = FIELD_SET(ulReg, CRT_HWC_ADDRESS, ENABLE, DISABLE); 
	POKE32(CRT_HWC_ADDRESS, ulReg);
	
	LEAVE();
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_entityEnter
 *  Description:  save console's registers
 * =====================================================================================
 */
void sm750_entityEnter(int entIndex,pointer private)
{
	ENTER();
	
	sm750_entityInit(entIndex, private);

	LEAVE();
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_entityLeave
 *  Description:  restore console's registers
 * =====================================================================================
 */
void sm750_entityLeave(int entIndex,pointer private)
{
	SMIHWPtr pHw = (SMIHWPtr)private;
	ENTER();
	if(xf86IsPrimaryPci(pHw->pPci))
	{
		/* Restore the registers */
		restore_reg_750((SMIHWPtr)private);
		/* Restore the vga fonts */
		sm750_restoreFonts((SMIHWPtr)private);
	}
	else
	{
		int val = PEEK32(PANEL_DISPLAY_CTRL);
		val = FIELD_SET(val,PANEL_DISPLAY_CTRL,TIMING,DISABLE);
		POKE32(PANEL_DISPLAY_CTRL, val);

		val = PEEK32(CRT_DISPLAY_CTRL);
		val = FIELD_SET(val,CRT_DISPLAY_CTRL,TIMING,DISABLE);
		POKE32(CRT_DISPLAY_CTRL, val);
	}
	LEAVE();
}
void sm750_saveText(ScrnInfoPtr pScrn)
{
	SMIPtr pSmi = SMIPTR (pScrn);

	ENTER();
	/* This functin called from entity init,
	Of course, it is the primary device */
	if(xf86IsPrimaryPci(pSmi->pHardware->pPci))
	{	
		/* Save the vga fonts */
		sm750_saveFonts(pSmi->pHardware);
		/* Save the registers */
		save_reg_750(pSmi->pHardware);
	}
	LEAVE();
}
/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  sm750_getMapResult
 *  Description:  calculate the frame buffer for the current screen
 * =====================================================================================
 */
void sm750_getMapResult(ScrnInfoPtr pScrn)
{
	vgaHWPtr hwp;
	SMIPtr pSmi = SMIPTR(pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
	ENTER();

	/* set video memory size */
	pSmi->videoRAMBytes = pHw->physize_mem / (pSmi->pHardware->dual);
	pScrn->videoRam = (pSmi->videoRAMBytes)>>10;/* kbytes*/

	/* set pScrn physica address*/
	pScrn->memPhysBase = pHw->phyaddr_mem;
	pScrn->memPhysBase += (pSmi->screen) * pSmi->videoRAMBytes;
    xf86Msg(X_INFO, "ilena, screen[%d]\n", pSmi->screen);
	/* set OFFSET */
	pScrn->fbOffset = pSmi->FBOffset = pScrn->memPhysBase - pHw->phyaddr_mem;

	/* set virtual address */
	pSmi->pFB = pHw->pMem;
	pSmi->pFB += (pSmi->screen) * pSmi->videoRAMBytes;
	/* cursor and reserved bound*/
#if !SMI_RANDR
    pSmi->FBCursorOffset = pSmi->videoRAMBytes - 2048;
#endif
	pSmi->FBReserved = pSmi->videoRAMBytes - 4096;

    DEBUG("pSmi->pFB = 0x%x, pSmi->FBOffset = 0x%x\n", pSmi->pFB, pSmi->FBOffset);

	if (!pSmi->width)
		pSmi->width = pScrn->displayWidth;
	if (!pSmi->height)
		pSmi->height = pScrn->virtualY;
	
	pSmi->Bpp = pScrn->bitsPerPixel / 8;
	pSmi->Stride = (pSmi->width * pSmi->Bpp + 15) & ~15;
	
    switch (pScrn->bitsPerPixel)
    {
        case 16:
            pSmi->Stride >>= 1;
            break;

        case 24:
        case 32:
            pSmi->Stride >>= 2;
            break;
    }

	LEAVE();
}

void sm750_handleOptions(ScrnInfoPtr pScrn)
{
	SMIPtr pSmi = SMIPTR (pScrn);
	int GPIOValue = 0;
	ENTER();
    if (pScrn->depth == 8)
    {
    	pScrn->rgbBits = 8;
    }
	if (xf86ReturnOptValBool (pSmi->Options, OPTION_HDMI_ENABLED, FALSE))
		pSmi->HDMIFeature = TRUE;
	else
		pSmi->HDMIFeature = FALSE;
	if (xf86ReturnOptValBool (pSmi->Options, OPTION_DP_ENABLED, FALSE))
		pSmi->DPFeature = TRUE;
	else
		pSmi->DPFeature = FALSE;
	XINF("HDMI output %s\n",(pSmi->HDMIFeature==TRUE)?"enable":"disable");
	XINF("DP output %s\n",(pSmi->DPFeature==TRUE)?"enable":"disable");
	if (pSmi->HDMIFeature)
	{
    	if (xf86GetOptValInteger (pSmi->Options, OPTION_HDMI_GPIO, &GPIOValue))
        	XINF("HDMI GPIO is found. The value is %d\n", GPIOValue);
        else
        {
            GPIOValue = 1213;
            XINF("HDMI GPIO isn't found. Use default value: %d\n", GPIOValue);
        }
        pSmi->i2c_HDMI_ClockGPIO = GPIOValue / 100;
        pSmi->i2c_HDMI_DataGPIO = GPIOValue % 100;
    }
	LEAVE();
}

ModeStatus sm750_validMode(ScrnInfoPtr pScrn,DisplayModePtr pMode)
{
	ENTER();
	LEAVE(MODE_OK);
}

void sm750_setMode(ScrnInfoPtr pScrn,DisplayModePtr pMode)
{
	SMIPtr pSmi = SMIPTR (pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
	I2CBusPtr bus;
	
	ENTER();

	mode_parameter_t parm;
	clock_type_t clock;
	
    if(pSmi->pci_burst && (pSmi->pHardware->pPci == SMI_718)) 
		enable_pci_burst_718(pHw);

#if SMI_RANDR
	if (pSmi->dispCtrl == PANEL)
		clock = PRIMARY_PLL;
	else if (pSmi->dispCtrl == CRT)
		clock = SECONDARY_PLL;
#else

	if (pSmi->screen == 0)
		clock = PRIMARY_PLL;
	else if (pSmi->screen == 1)
		clock = SECONDARY_PLL;
#endif
	/* Horizontal timing. */
    parm.horizontal_total = pMode->HTotal;
    parm.horizontal_display_end = pMode->HDisplay;
    parm.horizontal_sync_start = pMode->HSyncStart;
    parm.horizontal_sync_width = pMode->HSyncEnd - pMode->HSyncStart;
    parm.horizontal_sync_polarity = (pMode->Flags & V_PHSYNC)?POS:NEG;

    /* Vertical timing. */
    parm.vertical_total = pMode->VTotal;
    parm.vertical_display_end = pMode->VDisplay;
    parm.vertical_sync_start = pMode->VSyncStart;
    parm.vertical_sync_height = pMode->VSyncEnd - pMode->VSyncStart;
    parm.vertical_sync_polarity = (pMode->Flags & V_PVSYNC)?POS:NEG;

    /* Refresh timing. */
    parm.pixel_clock = pMode->Clock*1000; 
    parm.horizontal_frequency = roundDiv(parm.pixel_clock,
                                        parm.horizontal_total);
    parm.vertical_frequency = roundDiv(parm.horizontal_frequency,
                                      parm.vertical_total);
    
    /* Clock Phase. This clock phase only applies to Panel. */
    // SM750 & SM718 need set clock phase as 0 to make DVI signal normal.
    if (pSmi->DPFeature)
		parm.clock_phase_polarity = NEG;
	else
    	parm.clock_phase_polarity = POS;
    DEBUG("Set Mode H: %x; V: %x; clock: %x\n",
        parm.horizontal_total, parm.vertical_total, clock);
    
    ddk750_set_mmio(pHw->pReg,pHw->devId,0);
	
    ddk750_setModeTiming(&parm, clock);    
    
    LEAVE();
}

#if USE_VBE
void sm750_setModeVBE(ScrnInfoPtr pScrn, DisplayModePtr pMode)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
    VbeModeInfoData *data;
    VbeModeInfoBlock *modeInfo;
    int mode;
    int pitch, offset;
	mode_parameter_t parm;
	DisplayModePtr new_mode;

    ENTER();
	
    if (!pSmi->DualView)
    {
        sm750_setMode(pScrn, pMode);
        LEAVE();
    }
	
    data = (VbeModeInfoData *)pMode->Private;
    modeInfo = data->data;
    mode = data->mode | 1 << 14;

    if (!VBESetVBEMode(pSmi->pVbe, mode, data->block))
        return FALSE;

    ddk750_set_mmio(pHw->pReg, pHw->devId, 0);

    ddk750_copyPrimaryTiming2Secondary();
    
    /* when bpp=16 or 32,1368 * (bpp/8) is 16 pixel aligned*/
	pitch = (pSmi->width * (pScrn->bitsPerPixel / 8) + 15) & ~15;
	if (pMode->CrtcHDisplay == 0)
	    offset = (modeInfo->XResolution * (pScrn->bitsPerPixel / 8) + 15) & ~15;	
	else
	    offset = (pMode->CrtcHDisplay * (pScrn->bitsPerPixel / 8) + 15) & ~15;

    set_display_750(pHw, PANEL, pScrn->bitsPerPixel, pitch, pSmi->FBOffset, 
                    0, 0);
    set_display_750(pHw, CRT,  pScrn->bitsPerPixel, pitch, pSmi->FBOffset + offset, 
                    0, 0);

    pScrn->vtSema = TRUE;

    LEAVE();
}
#endif

void sm750_setDisplay(ScrnInfoPtr pScrn, DisplayModePtr mode)
{
	SMIPtr pSmi = SMIPTR (pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
	int bpp = pScrn->bitsPerPixel;
	int pitch;
	
	ENTER();

	display_t channel;
#if SMI_RANDR
	if (pSmi->dispCtrl == PANEL)
		channel = PANEL;
	else if (pSmi->dispCtrl == CRT)
		channel = CRT;
#else	
	if(pSmi->IsPrimary)
		channel = PANEL;
	else
		channel = CRT;
#endif
    /* 
     * Pitch value calculation in Bytes.
     * Usually, it is (screen width) * (byte per pixel).
     * However, there are cases that screen width is not 16 pixel aligned, which is
     * a requirement for some OS and the hardware itself.
     * For standard 4:3 resolutions: 320, 640, 800, 1024 and 1280, they are all
     * 16 pixel aligned and pitch is simply (screen width) * (byte per pixel).
     *   
     * However, 1366 resolution or 1368, for example, has to be adjusted for 16 pixel aligned.
     */
    /* "+ 15) & ~15)" This calculation has no effect on 640, 800, 1024 and 1280. */
	pitch = (pSmi->width * (bpp / 8) + 15) & ~15;	/* when bpp=16 or 32,1368 * (bpp/8) is 16 pixel aligned*/
	xf86Msg(X_INFO,"sm750:set Display:pitch: %x\n", pitch);
	
	set_display_750(pHw, channel, bpp, pitch, pSmi->FBOffset, mode->HDisplay, mode->HTotal);
	LEAVE();
}

void sm750_adjustFrame(ScrnInfoPtr pScrn,int offset)
{
	ENTER();	
	LEAVE();
}

void sm750_closeAllScreen(SMIHWPtr pHw)
{
	ENTER();
	SMI750HWPtr	p750Hw;
	p750Hw = (SMI750HWPtr)pHw;

	if(p750Hw->pRegSave)
	{
		xf86Msg(X_INFO,"Close Screen Free saved reg\n");
		xfree(p750Hw->pRegSave);
		p750Hw->pRegSave = NULL;
	}

	if(p750Hw->fonts)
	{
		xf86Msg(X_INFO,"Close Screen Free saved fonts\n");
		xfree(p750Hw->fonts);
		p750Hw->fonts = NULL;
	}
	xfree(p750Hw);
	LEAVE();
}

/* Save vga fonts */
static void sm750_saveFonts(SMIHWPtr pHw)
{	
	SMI750HWPtr	p750Hw = (SMI750HWPtr)pHw;

	ENTER();
	
	/* leave if in graphic mode */
	if(get_vga_mode_750(pHw) & 0x2)
		LEAVE();

	memcpy((char *)p750Hw->fonts,(char *)pHw->pMem + KB(0),KB(64));
	
	/* not use legency method to access vga fonts , or multi-card will cry */

 	LEAVE();
}

static void sm750_restoreFonts(SMIHWPtr pHw)
{
	SMI750HWPtr	p750Hw = (SMI750HWPtr)pHw;

	ENTER();
	
	if(p750Hw->fonts)
		memcpy((char *)pHw->pMem + KB(0),(char *)p750Hw->fonts,KB(64));
	
	/* not use legency method or multi-card cries */

	LEAVE();
}

int sm750_totalFB(SMIHWPtr pHw)
{
	unsigned int total_memory;
	ENTER();
	
	ddk750_set_mmio(pHw->pReg,pHw->devId,0);
	total_memory = ddk750_getVMSize();
	
	LEAVE(total_memory);
}

void sm750_loadPalette (ScrnInfoPtr pScrn, int numColors, 
        int *indicies, LOCO * colors, VisualPtr pVisual)
{
	ENTER();
#if (SMI_RANDR && RANDR_12_INTERFACE)
    	xf86CrtcConfigPtr crtcConf = XF86_CRTC_CONFIG_PTR(pScrn);
    	int crtc_idx,i,j;

   	 if(pScrn->bitsPerPixel == 16){
        /* Expand the RGB 565 palette into the 256-elements LUT */

        for(crtc_idx=0; crtc_idx<crtcConf->num_crtc; crtc_idx++){
            SMICrtcPrivatePtr crtcPriv = SMICRTC(crtcConf->crtc[crtc_idx]);

            for(i=0; i<numColors; i++){
                int idx = indicies[i];

                if(idx<32){
                    for(j=0; j<8; j++){
                        crtcPriv->lut_r[idx*8 + j] = colors[idx].red << 8;
                        crtcPriv->lut_b[idx*8 + j] = colors[idx].blue << 8;
                    }
                }

                for(j=0; j<4; j++)
                    crtcPriv->lut_g[idx*4 + j] = colors[idx].green << 8;
            }

            crtcPriv->load_lut(crtcConf->crtc[crtc_idx]);
        }
    }else{
        for(crtc_idx=0; crtc_idx<crtcConf->num_crtc; crtc_idx++){
            SMICrtcPrivatePtr crtcPriv = SMICRTC(crtcConf->crtc[crtc_idx]);

            for(i = 0; i < numColors; i++) {
                int idx = indicies[i];

                crtcPriv->lut_r[idx] = colors[idx].red << 8;
                crtcPriv->lut_g[idx] = colors[idx].green << 8;
                crtcPriv->lut_b[idx] = colors[idx].blue << 8;
            }

            crtcPriv->load_lut(crtcConf->crtc[crtc_idx]);
        }
    }
#else 
	if(pScrn->depth == 8){
	int idx, i;
    unsigned long paletteconst[256];
	for(i = 0; i < numColors; i++){
		idx = indicies[i];
	    paletteconst[idx] = colors[idx].blue | (colors[idx].green << 8) | (colors[idx].red << 16);
		POKE32(PANEL_PALETTE_RAM + 4 * idx, paletteconst[idx]);
		POKE32(CRT_PALETTE_RAM + 4 * idx, paletteconst[idx]);
		}
	}
#endif      
        LEAVE();
}

#if SMI_RANDR
void sm750_I2CInit(ScrnInfoPtr pScrn)
{    
	SMIPtr pSmi = SMIPTR(pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
	int cnt = pSmi->DualView?2:1;
	int index;
	I2CBusPtr ptr[2] = {NULL,NULL};
	static char * sm750_name[] = {"I2C Bus PanelPath","I2C Bus CrtPath"};	
	ENTER();

	pfn_I2CPutBits_750[0] = i2c_putbits_panel_750;
	pfn_I2CPutBits_750[1] = i2c_putbits_crt_750;
	pfn_I2CGetBits_750[0] = i2c_getbits_panel_750;
	pfn_I2CGetBits_750[1] = i2c_getbits_crt_750;

	index= 0 ;        
	while(index < cnt)
	{       
	    if(ptr[index] == NULL )
	    {
	    	I2CBusPtr I2CPtr = xf86CreateI2CBusRec();
	    	if (I2CPtr == NULL)
	    	    return FALSE;

			I2CPtr->scrnIndex  = pScrn->scrnIndex;
			I2CPtr->BusName  = sm750_name[index];
			I2CPtr->I2CPutBits = pfn_I2CPutBits_750[index];
			I2CPtr->I2CGetBits = pfn_I2CGetBits_750[index];				
			
			        	
	    	I2CPtr->DriverPrivate.ptr = (void *)xalloc(sizeof(int));

	    	if (!xf86I2CBusInit(I2CPtr)){				
	    	    xfree(I2CPtr->DriverPrivate.ptr);
	    	    xf86DestroyI2CBusRec(I2CPtr, TRUE, TRUE);
	    	    LEAVE(FALSE);
	    	}        	
	 
	    	ptr[index] = I2CPtr;
			/* 	for sm712: 0 means CRT HEAD i2c bus
				for sm750: 0 means PANEL HEAD i2c bus, 
				note that head is not pll
			*/
	    	*((int *)I2CPtr->DriverPrivate.ptr) = index;
	    }
	    index++;
	}

	pSmi->I2C_primary = ptr[0];
	pSmi->I2C_secondary = ptr[1];

	init_i2c_750(pHw);

	LEAVE(TRUE);
}	
#endif

void sm750_VideoReset(ScrnInfoPtr pScrn)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    	SMIHWPtr pHw = pSmi->pHardware;
    SMI_PortPtr pPort = (SMI_PortPtr) pSmi->ptrAdaptor->pPortPrivates[0].ptr;
    int r, g, b;

	ENTER();

    switch (pScrn->depth)
    {
        case 8:
            WRITE_DCR(pHw, DCR08, pPort->Attribute[XV_COLORKEY] & 0x00FF);
            break;
        case 15:
        case 16:
            WRITE_DCR(pHw, DCR08, pPort->Attribute[XV_COLORKEY] & 0xFFFF);
            break;
        default:
            r = (pPort->Attribute[XV_COLORKEY] & pScrn->mask.red) >> pScrn->offset.red;
            g = (pPort->Attribute[XV_COLORKEY] & pScrn->mask.green) >> pScrn->offset.green;
            b = (pPort->Attribute[XV_COLORKEY] & pScrn->mask.blue) >> pScrn->offset.blue;
            WRITE_DCR(pHw, DCR08, ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
            break;
    }

	LEAVE();
}
