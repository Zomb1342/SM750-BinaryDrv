/* Header:   //Mercury/Projects/archives/XFree86/4.0/smi_hwcurs.c-arc   1.12   27 Nov 2000 15:47:48   Frido  $ */

/*
Copyright (C) 1994-1999 The XFree86 Project, Inc.  All Rights Reserved.
Copyright (C) 2000 Silicon Motion, Inc.  All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FIT-
NESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
XFREE86 PROJECT BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the names of the XFree86 Project and
Silicon Motion shall not be used in advertising or otherwise to promote the
sale, use or other dealings in this Software without prior written
authorization from the XFree86 Project and Silicon Motion.
*/
/* $XFree86: xc/programs/Xserver/hw/xfree86/drivers/siliconmotion/smi_hwcurs.c,v 1.2 2001/03/03 22:26:13 tsi Exp $ */

/*! THIS FILE COME FROM OLD NO RANDR DRIVER. ONLY FOR SM750HS !*/

#include "../smi_common.h"
#include "../ddk750/ddk750_reg.h"
#include "../ddk750/ddk750_regde.h"
#include "../ddk750/ddk750_help.h"
#include "../smi_dbg.h"
#include "cursorstr.h"

#if !SMI_RANDR
#define MAX_CURSOR		32
#define SMI750_CURSOR_WIDTH	 32
#define SMI750_CURSOR_HEIGHT 32

/* SM750 Panel Cursor Control */
#define DCRF0						0x0800F0
#define DCRF4						0x0800F4
#define DCRF8						0x0800F8
#define DCRFC						0x0800FC
/* SM750 CRT Cursor Control */
#define DCR230						0x080230
#define DCR234						0x080234
#define DCR238						0x080238
#define DCR23C						0x08023C

/* HWCursor definitons for Panel AND CRT */                                      
#define SMI750_MASK_HWCENABLE        0x80000000
#define SMI750_MASK_MAXBITS             0x0000FFFF
#define SMI750_MASK_BOUNDARY          0x00000800

static void SMI_SetCursorColors(ScrnInfoPtr pScrn, int bg, int fg);

static void
SMI_LoadCursorImage(ScrnInfoPtr pScrn, unsigned char *src)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	SMIHWPtr pHw = pSmi->pHardware;
	CARD32 RegVal;
	int i = 0;
	ENTER();

	SMI_SetCursorColors(pScrn, 0, 0xffffff);
	/* Copy cursor image to framebuffer storage */
	//memcpy(pSmi->pFB + pSmi->FBCursorOffset, src, 1024);   //when cursor size is 64*64, image is 64*64/4
    while(i < 64){
		if(i < SMI750_CURSOR_HEIGHT){
			//memcpy(pHw->pMem + pSmi->FBCursorOffset + MAX_CURSOR / 4 * i, image + SMI750_CURSOR_WIDTH / 4 * i, SMI750_CURSOR_WIDTH / 4);  // when cursor size is 32*32, image size is 32*32/4
			//memset(pHw->pMem + pSmi->FBCursorOffset + MAX_CURSOR / 4 * i + SMI750_CURSOR_WIDTH / 4, 0, (MAX_CURSOR - SMI750_CURSOR_WIDTH) / 4);
    		memcpy(pHw->pMem + pSmi->FBCursorOffset + 16 * i, src + 8 * i, 8);
			memset(pHw->pMem + pSmi->FBCursorOffset + 16 * i + 8 , 0, 8);
		}
		else{
			//memset(pHw->pMem + pSmi->FBCursorOffset + MAX_CURSOR / 4 * i, 0, MAX_CURSOR / 4);
			memset(pHw->pMem + pSmi->FBCursorOffset + 16 * i, 0, 16);
		}
		i++;
    }

    /* Write address*/	
	if (!pScrn->scrnIndex){
		RegVal = SMI750_MASK_HWCENABLE | pSmi->FBCursorOffset;
		POKE32(DCRF0, RegVal);	/* Panel HWC Addr */	
	}
	else{
		RegVal = SMI750_MASK_HWCENABLE | pSmi->FBCursorOffset;
		POKE32(DCR230, RegVal);	/* CRT	 HWC Addr */
	}
	
    LEAVE();
}

static void
SMI_ShowCursor(ScrnInfoPtr pScrn)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	CARD32 RegVal;
	
	if (!pScrn->scrnIndex){
		RegVal  = PEEK32(DCRF0);
		RegVal |= SMI750_MASK_HWCENABLE;
		POKE32(DCRF0, RegVal);
	}
	else{
		RegVal  = PEEK32(DCR230);
		RegVal |= SMI750_MASK_HWCENABLE;
		POKE32(DCR230, RegVal);
	}
}

static void
SMI_HideCursor(ScrnInfoPtr pScrn)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	CARD32 RegVal;

	if (!pScrn->scrnIndex){
		RegVal	= PEEK32(DCRF0);
		/*
		 * Belcon: Fix #001
		 *   Save hardware cursor address register
		 */
		if(pSmi->dcrF0 == 0) {
			pSmi->dcrF0 = RegVal;
		}
		/* #001 ended */
		RegVal &= ~SMI750_MASK_HWCENABLE;
		POKE32(DCRF0, RegVal);
	}
	else{
		
		RegVal = PEEK32(DCR230);

		if(pSmi->dcr230 == 0){
			pSmi->dcr230 = RegVal;
		}
		RegVal   &= ~SMI750_MASK_HWCENABLE;
		POKE32(DCR230, RegVal);
	}
       
}

static void
SMI_SetCursorPosition(ScrnInfoPtr pScrn, int x, int y)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	int xoff, yoff;
	ENTER();

	/* Calculate coordinates for rotation */
	switch (pSmi->rotate)
	{
		default:
			xoff = x;
			yoff = y;
			break;

		case SMI_ROTATE_CW:
			xoff = pSmi->ShadowHeight - y - MAX_CURSOR;
			yoff = x;
			break;

		case SMI_ROTATE_CCW:
			xoff = y;
			yoff = pSmi->ShadowWidth - x - MAX_CURSOR;
			break;
	}

    CARD32 hwcLocVal;

    if (xoff >= 0)
    {
    	hwcLocVal = (xoff & SMI750_MASK_MAXBITS);
    }
   	else
    {
    	hwcLocVal = (((-xoff) & SMI750_MASK_MAXBITS) | SMI750_MASK_BOUNDARY);
    }

    if (yoff >= 0)
    {
    	hwcLocVal |= (yoff & SMI750_MASK_MAXBITS)<<16;
    }
    else
    {
    	hwcLocVal |= (((-yoff) & SMI750_MASK_MAXBITS) | SMI750_MASK_BOUNDARY)<<16;
    }

    /* Program combined coordinates */
	if (!pScrn->scrnIndex)
		POKE32(DCRF4, hwcLocVal);  /* Panel HWC Location */
	else
		POKE32(DCR234, hwcLocVal);  /* CRT   HWC Location */   
	LEAVE();
}

static void
SMI_SetCursorColors(ScrnInfoPtr pScrn, int bg, int fg)
{
    SMIPtr pSmi = SMIPTR(pScrn);
	unsigned char packedFG, packedBG;
	ENTER();
	/*if (bg == fg) {
		return;
	}*/

    /* for the SMI501 HWCursor, there are 4 possible colors, one of which
     * is transparent:  M,S:  0,0 = Transparent
     *						  0,1 = color 1
     *						  1,0 = color 2
     *						  1,1 = color 3
     *  To simplify implementation, we use color2 == bg and
     *									   color3 == fg
     *	Color 1 is don't care, so we set it to color 2's value
     */
	unsigned  int packedFGBG;
        
	/* Pack the true color components into 16 bit RGB -- 5:6:5 */
	packedFGBG  =  (bg & 0xF80000) >> 8
				    |  (bg & 0x00FC00) >> 5
				    |  (bg & 0x0000F8) >> 3
				    ;

	packedFGBG |= (bg & 0xF80000) << 8
				    | (bg & 0x00FC00) << 11
				    | (bg & 0x0000F8) << 13
				    ;
                   
	if (!pScrn->scrnIndex)
		POKE32(DCRF8, packedFGBG);    /* Panel HWC Color 1,2 */
	else
		POKE32(DCR238, packedFGBG);    /* CRT	HWC Color 1,2 */
    
	packedFGBG  =  (fg & 0xF80000) >> 8
				    |  (fg & 0x00FC00) >> 5
				    |  (fg & 0x0000F8) >> 3
				    ;
	if (!pScrn->scrnIndex)
		POKE32(DCRFC, packedFGBG);	/* Panel HWC Color 3 */
	else
		POKE32(DCR23C, packedFGBG);	/* CRT	 HWC Color 3 */        
	LEAVE();
}

Bool
SMI_HWCursorInit(ScreenPtr pScreen)
{

	ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
	xf86CursorInfoPtr infoPtr;
	CARD32 uiPanelTmp;
	Bool ret;
	ENTER();
	
	/* Create cursor infor record */
	infoPtr = xf86CreateCursorInfoRec();
	if (infoPtr == NULL)
	{
		LEAVE(FALSE);
	}
	
    pSmi->CursorInfoRec = infoPtr;

    infoPtr->MaxWidth  = SMI750_CURSOR_WIDTH;
    infoPtr->MaxHeight = SMI750_CURSOR_HEIGHT; 

    {   
    	infoPtr->Flags	= HARDWARE_CURSOR_SOURCE_MASK_INTERLEAVE_1
						| HARDWARE_CURSOR_SWAP_SOURCE_AND_MASK
						| HARDWARE_CURSOR_AND_SOURCE_WITH_MASK;  
    }    

    infoPtr->SetCursorColors   = SMI_SetCursorColors;
    infoPtr->SetCursorPosition = SMI_SetCursorPosition;
    infoPtr->LoadCursorImage   = SMI_LoadCursorImage;
    infoPtr->HideCursor        = SMI_HideCursor;
    infoPtr->ShowCursor        = SMI_ShowCursor;
    infoPtr->UseHWCursor       = TRUE;

	/* Proceed with cursor initialization */
    ret = xf86InitCursor(pScreen, infoPtr);
	/* Force to use hardware cursor */
	xf86ForceHWCursor(pScreen, TRUE);
	SMI_SetCursorColors(pScrn, 0, 0xffffff);

	LEAVE(ret);
}
#endif
