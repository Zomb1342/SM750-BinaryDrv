/*******************************************************************
* 
*         Copyright (c) 2007 by Silicon Motion, Inc. (SMI)
* 
*  All rights are reserved. Reproduction or in part is prohibited
*  without the written consent of the copyright owner.
* 
*  I2C.H --- Voyager GX SDK 
*  This file contains the definitions for SW I2C.
* 
*******************************************************************/
#ifndef _HDMI_SWI2C_H_
#define _HDMI_SWI2C_H_

/* Default i2c CLK and Data GPIO. These are the default i2c pins */
//#define HDMI_DEFAULT_I2C_SCL                     17//30
//#define HDMI_DEFAULT_I2C_SDA                     18//31
#define HDMI_DEFAULT_I2C_SCL                    12
#define HDMI_DEFAULT_I2C_SDA                    13
/*
 * This function initializes the i2c attributes and bus
 *
 * Parameters:
 *      i2cClkGPIO  - The GPIO pin to be used as i2c SCL
 *      i2cDataGPIO - The GPIO pin to be used as i2c SDA
 *
 * Return Value:
 *      -1   - Fail to initialize the i2c
 *       0   - Success
 */
long HDMI_swI2CInit(
    unsigned char i2cClkGPIO, 
    unsigned char i2cDataGPIO
);

int HDMI_checkConnected(unsigned char deviceAddress);

/*
 *  This function reads the slave device's register
 *
 *  Parameters:
 *      deviceAddress   - i2c Slave device address which register
 *                        to be read from
 *      registerIndex   - Slave device's register to be read
 *
 *  Return Value:
 *      Register value
 */
unsigned char HDMI_swI2CReadReg(
    unsigned char deviceAddress, 
    unsigned char registerIndex
);


long HDMI_swI2CReadBlock(
    unsigned char deviceAddress, 
    unsigned char registerIndex,
    unsigned char len,
    unsigned char* data_buffer
);

/*
 *  This function writes a value to the slave device's register
 *
 *  Parameters:
 *      deviceAddress   - i2c Slave device address which register
 *                        to be written
 *      registerIndex   - Slave device's register to be written
 *      data            - Data to be written to the register
 *
 *  Result:
 *          0   - Success
 *         -1   - Fail
 */
long HDMI_swI2CWriteReg(
    unsigned char deviceAddress, 
    unsigned char registerIndex, 
    unsigned char data
);

long HDMI_swI2CWriteReg_NoAck(
    unsigned char deviceAddress, 
    unsigned char registerIndex, 
    unsigned char data
);



#endif  /* _SWI2C_H_ */
