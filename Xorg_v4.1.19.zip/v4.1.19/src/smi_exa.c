/*
Copyright (C) 1994-1999 The XFree86 Project, Inc.  All Rights Reserved.
Copyright (C) 2000 Silicon Motion, Inc.  All Rights Reserved. 
Copyright (c) 2012 by Silicon Motion, Inc. (SMI)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FIT-
NESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
XFREE86 PROJECT BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the names of The XFree86 Project and
Silicon Motion shall not be used in advertising or otherwise to promote the
sale, use or other dealings in this Software without prior written
authorization from The XFree86 Project or Silicon Motion.
*/

#include "smi_dbg.h"
#include "smi_common.h"
#if (SMI_RANDR && RANDR_12_INTERFACE)
#include "smi_crtc.h"
#endif
#include "mipict.h"
#include "ddk750/ddk750.h"
#include "ddk750/ddk750_sw2d.h"
#include "ddk750/ddk750_2d.h"
#include "ddk750/ddk750_regde.h"

#ifdef HAVE_EXA

extern int PEEK32(addr) ;
extern void POKE32(addr,data);
extern void deSetPixelFormat(unsigned long bpp);
//extern	unsigned long swRasterOp2(unsigned long S, unsigned long D, unsigned long rop2);
extern long deWaitForNotBusy(void);

static void
SMI_EXASync(ScreenPtr pScreen, int marker);
//static void SMI_EngineReset(ScrnInfoPtr pScrn);

static Bool SMI_PrepareSolid(PixmapPtr pPixmap,int alu, Pixel planemask, Pixel fg);
static void SMI_Solid(PixmapPtr pPixmap, int x1, int y1, int x2, int y2);
static void SMI_DoneSolid(PixmapPtr pPixmap);

static Bool
SMI_PrepareCopy(PixmapPtr pSrcPixmap, PixmapPtr pDstPixmap,
		int xdir, int ydir, int alu, Pixel planemask);

static void
SMI_Copy(PixmapPtr pDstPixmap, int srcX, int srcY, int dstX, int dstY, int width, int height);

static void
SMI_DoneCopy(PixmapPtr pDstPixmap);

static Bool
SMI_CheckComposite(int op, PicturePtr pSrcPicture, PicturePtr pMaskPicture, PicturePtr pDstPicture);
static Bool
SMI_PrepareComposite(int op, PicturePtr pSrcPicture, PicturePtr pMaskPicture, PicturePtr pDstPicture,
                     PixmapPtr pSrc, PixmapPtr pMask, PixmapPtr pDst);
static void
SMI_Composite(PixmapPtr pDst, int srcX, int srcY, int maskX, int maskY,
              int dstX, int dstY, int width, int height);
static void
SMI_DoneComposite(PixmapPtr pDst);

Bool
SMI_UploadToScreen(PixmapPtr pDst, int x, int y, int w, int h, char *src, int src_pitch);

Bool
SMI_DownloadFromScreen(PixmapPtr pSrc, int x, int y, int w, int h, char *dst, int dst_pitch);

CARD8 SMI_BltRop[16] =	/* table stolen from KAA */
{
    /* GXclear      */      0x00,         /* 0 */
    /* GXand        */      0x88,         /* src AND dst */
    /* GXandReverse */      0x44,         /* src AND NOT dst */
    /* GXcopy       */      0xCC,         /* src */
    /* GXandInverted*/      0x22,         /* NOT src AND dst */
    /* GXnoop       */      0xAA,         /* dst */
    /* GXxor        */      0x66,         /* src XOR dst */
    /* GXor         */      0xEE,         /* src OR dst */
    /* GXnor        */      0x11,         /* NOT src AND NOT dst */
    /* GXequiv      */      0x99,         /* NOT src XOR dst */
    /* GXinvert     */      0x55,         /* NOT dst */
    /* GXorReverse  */      0xDD,         /* src OR NOT dst */
    /* GXcopyInverted*/     0x33,         /* NOT src */
    /* GXorInverted */      0xBB,         /* NOT src OR dst */
    /* GXnand       */      0x77,         /* NOT src OR NOT dst */
    /* GXset        */      0xFF,         /* 1 */
};

CARD8 SMI_SolidRop[16] =	/* table stolen from KAA */
{
    /* GXclear      */      0x00,         /* 0 */
    /* GXand        */      0xA0,         /* src AND dst */
    /* GXandReverse */      0x50,         /* src AND NOT dst */
    /* GXcopy       */      0xF0,         /* src */
    /* GXandInverted*/      0x0A,         /* NOT src AND dst */
    /* GXnoop       */      0xAA,         /* dst */
    /* GXxor        */      0x5A,         /* src XOR dst */
    /* GXor         */      0xFA,         /* src OR dst */
    /* GXnor        */      0x05,         /* NOT src AND NOT dst */
    /* GXequiv      */      0xA5,         /* NOT src XOR dst */
    /* GXinvert     */      0x55,         /* NOT dst */
    /* GXorReverse  */      0xF5,         /* src OR NOT dst */
    /* GXcopyInverted*/     0x0F,         /* NOT src */
    /* GXorInverted */      0xAF,         /* NOT src OR dst */
    /* GXnand       */      0x5F,         /* NOT src OR NOT dst */
    /* GXset        */      0xFF,         /* 1 */
};


#if 0
//stolen from http://tronche.com/gui/x/xlib/GC/manipulating.html

the alu(rop value) will be like this::::

GXclear		0x0 	0
GXand		0x1 	src AND dst
GXandReverse		0x2 	src AND NOT dst
GXcopy		0x3 	src
GXandInverted		0x4 	(NOT src) AND dst
GXnoop		0x5 	dst
GXxor		0x6 	src XOR dst
GXor		0x7 	src OR dst
GXnor		0x8 	(NOT src) AND (NOT dst)
GXequiv		0x9 	(NOT src) XOR dst
GXinvert		0xa 	NOT dst
GXorReverse		0xb 	src OR (NOT dst)
GXcopyInverted		0xc 	NOT src
GXorInverted		0xd 	(NOT src) OR dst
GXnand		0xe 	(NOT src) OR (NOT dst)
GXset		0xf 	1
#endif 


static void
SMI_EXASync(ScreenPtr pScreen, int marker)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
	uint32_t i = 0x1000000;

    //ENTER();

    while (i--)
    {
        uint32_t dwVal = PEEK32(SYSTEM_CTRL);
        if ((FIELD_GET(dwVal, SYSTEM_CTRL, DE_STATUS)      == SYSTEM_CTRL_DE_STATUS_IDLE) &&
            (FIELD_GET(dwVal, SYSTEM_CTRL, DE_FIFO)        == SYSTEM_CTRL_DE_FIFO_EMPTY) &&
            (FIELD_GET(dwVal, SYSTEM_CTRL, CSC_STATUS)     == SYSTEM_CTRL_CSC_STATUS_IDLE) &&
            (FIELD_GET(dwVal, SYSTEM_CTRL, DE_MEM_FIFO)    == SYSTEM_CTRL_DE_MEM_FIFO_EMPTY))
        {
            return;//LEAVE(); /* Return because engine idle */
        }
    }

	/* Return because time out */
    //LEAVE();
}

void SMI_SetClippingRectangle(ScrnInfoPtr pScrn, int left, int top, int right,
			 int bottom)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    ENTER();
    
    pSmi->ScissorsLeft = (top << 16) | (left & 0xFFFF) | 0x2000;
    pSmi->ScissorsRight = (bottom << 16) | (right & 0xFFFF);
    pSmi->ClipTurnedOn = FALSE;
    deSetClipping(1, pSmi->ScissorsLeft&0xffff, pSmi->ScissorsLeft >> 16,
                    pSmi->ScissorsRight&0xffff, pSmi->ScissorsRight >> 16);		
	LEAVE();

}


void SMI_DisableClipping(ScrnInfoPtr pScrn)
{
    SMIPtr pSmi = SMIPTR(pScrn);
    ENTER();
    
    pSmi->ScissorsLeft = 0;
    pSmi->ClipTurnedOn = FALSE;
    deWaitForNotBusy();
    deSetClipping(0, pSmi->ScissorsLeft&0xFFFF, pSmi->ScissorsLeft>>16, 
                    pSmi->ScissorsRight&0xFFFF, pSmi->ScissorsRight>>16);
                    
    LEAVE();
}

void SMI_EngineReset(ScrnInfoPtr pScrn)
{  

    SMIPtr pSmi = SMIPTR(pScrn);
    CARD32 DEDataFormat = 0;
    int i, stride;

    //int xyAddress[] = { 320, 400, 512, 640, 800, 1024, 1280, 1600, 2048 };

    ENTER();
    //deInit();
       
    if (deWaitForNotBusy()!=0) {
		xf86Msg(X_INFO, "engine reset error\n");
        LEAVE(FALSE);
    }
    enable2DEngine(1);//by ilena

	pSmi->Stride = (pScrn->displayWidth * pSmi->Bpp + 15) & ~15;
    switch (pScrn->bitsPerPixel)
    {
        case 8:
            DEDataFormat = 0x00000000;
            break;

        case 16:
            pSmi->Stride >>= 1;
            DEDataFormat = 0x00100000;
            break;

        case 24:
            DEDataFormat = 0x00300000;
            break;

        case 32:
            pSmi->Stride >>= 2;
            DEDataFormat = 0x00200000;
            break;
    }

    deReset();
    WRITE_DPR (pSmi->pHardware, 0x1C, DEDataFormat);
    deSetTransparency(0, 0, 0, 0);
    WRITE_DPR(pSmi->pHardware, 0x24, 0xFFFFFFFF);
    WRITE_DPR(pSmi->pHardware, 0x28, 0xFFFFFFFF);
    WRITE_DPR(pSmi->pHardware, 0x40, pScrn->fbOffset);
    WRITE_DPR(pSmi->pHardware, 0x44, pScrn->fbOffset);
    SMI_DisableClipping(pScrn);   
    
    LEAVE();
}

unsigned char readByte(void *pAddr)
{
    //void *pAddr;
	return *(volatile unsigned char *)(pAddr);

}

void writeByte(void *pAddr, unsigned char value)
{
	*(volatile unsigned char *)(pAddr) = value;
}

unsigned short readWord(void *pAddr)
{
    //void *pAddr;
	return *(volatile unsigned short *)(pAddr);

}

void writeWord(void *pAddr, unsigned short value)
{
	*(volatile unsigned short *)(pAddr) = value;
}

unsigned long readDWord(void *pAddr)
{
    //void *pAddr;

	return *(volatile unsigned long *)(pAddr);

}

void writeDWord(void *pAddr, unsigned long value)
{

	*(volatile unsigned long *)(pAddr) = value;
}

unsigned short Change32to16(unsigned long color)
{
	unsigned short ret;
	unsigned char r, g, b;
	r=((color>>24)>>3)&0x1F;
	g=((color>>16)>>2)&0x3F;
	b=((color>>8)>>3)&0x1F;
	ret = (r<<11)|(g<<5)|(b);
	return ret;
}

//we need to change it because they are incorrect....
unsigned long SMI_swRasterOp2(unsigned long S, unsigned long D, unsigned long rop2)
{
    unsigned long opValue;
	//if(rop2 != 0x3)
	//	xf86Msg(X_INFO, "Raster:color=[%x],destColor16=[%x], rop2=[%x]\n", S,D, rop2 );
	//return D;

    switch (rop2)
    {
    case 0: /* GXclear 		- 0 */
    opValue = 0;
    break;
    case 1: /* GXand 		- S & D */
    opValue = S & D;
    break;
    case 2: /* GXandReverse  	- S & !D */
    opValue = S & ~D;
    break;
    case 3: /* GXcopy 		- S */
    opValue = S;
    break;
    case 4: /* GXandInverted 	- !S & D */
    opValue = ~S & D;
    break;
    case 5: /* GXnoop		- D */
    opValue = D;
    break;
    case 6: /* GXxor 		- S ^ D */
    opValue = S ^ D;
    break;
    case 7: /* GXor		- S | D */
    opValue = S | D;
    break;
    case 8: /* GXnor 		- !S & !D */
    opValue = ~(S | D);
    break;
    case 9: /* GXequiv		- !S ^ D */
    opValue = ~S ^ D;
    break;
    case 0xA: /* GXinvert		- !D */
    opValue = ~D;
    break;
    case 0xB: /* GXorReverse	- S | !D */
    opValue = S | ~D;
    break;
    case 0xC: /* GXcopyInverted	- !S */
    opValue = ~S;
    break;
    case 0xD: /* GXorInverted	- !S | D */
    opValue = ~S | D;
    break;
    case 0xE: /* GXnand		- !S | !D */
    opValue = ~(S & D);
    break;
    case 0xF: /* GXset		- 1 */
    opValue = 0xFFFFFFFF;
    break;
    default:
        opValue = S;
        break;
    }
	//xf86Msg(X_INFO, "dddddddddddddd, opv=[%x],destColor16=[%x], rop2=[%x]", opValue );

    return(opValue);
}


/*
 * This function set up a pixel value in the frame buffer.
 *
 * Note:
 * 1) It can only set pixel within the frame buffer.
 * 2) This function is NOT for drawing surface created in system memory.
 *
 */
void SMI_swSetPixel(
void *pFB,
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x, 
unsigned long y,        /* Position (X, Y) to set in pixel value */
unsigned long color,    /* Color */
unsigned long rop2)     /* ROP value */
{
    unsigned long destAddr;
    unsigned char  destColor8;
    unsigned short destColor16;
    unsigned long  destColor32;

    destAddr = (y * pitch) + (x * bpp/8) + destBase;

    switch (bpp)
    {
        case 8:
            destColor8 = readByte(pFB + destAddr);
            destColor8 = (unsigned char)SMI_swRasterOp2(color, destColor8, rop2);
            writeByte(pFB + destAddr, destColor8);
            break;

        case 16:
			//xf86Msg(X_INFO, "ccccccccccc, ");
            destColor16 = readWord(pFB + destAddr);
			//if((y%80 == 0)&&(x%20 ==0 ))
			//xf86Msg(X_INFO, "rrrr, color=[%x]\n", destColor16);
			//xf86Msg(X_INFO, "dddddddddddddd, color=[%x],destColor16=[%x], rop2=[%x]", color,destColor16, rop2 );
            destColor16 = (unsigned short)SMI_swRasterOp2(color, destColor16, rop2);

            writeWord(pFB + destAddr, destColor16);
			//xf86Msg(X_INFO, "ffffffffffff, ");
            break;

        case 32:
        default:
            destColor32 = readDWord(pFB + destAddr);
            destColor32 = (unsigned long)SMI_swRasterOp2(color, destColor32, rop2);
            //destColor32 = 0xffffffff;
            writeDWord(pFB + destAddr, destColor32);
            break;
    }
}


/*
 * This function gets a pixel value in the frame buffer.
 *
 * Note:
 * 1) It can only get pixel within the frame buffer.
 * 2) This function is NOT for drawing surface created in system memory.
 * 3) This function always return a 32 bit pixel value disregard bpp = 8, 16, or 32.
 *    The calling funtion has to type cast the return value into Byte, word or 
 *    DWord according to BPP.
 *
 */
unsigned long SMI_swGetPixel(
void *pFB,
unsigned long destBase, /* Base address of destination surface counted from beginning of video frame buffer */
unsigned long pitch,    /* Pitch value of destination surface in BYTES */
unsigned long bpp,      /* Color depth of destination surface: 8, 16 or 32 */
unsigned long x, 
unsigned long y)        /* Position (X, Y) to set in pixel value */
{
    unsigned long destAddr;
    unsigned long pixel = 0;

    destAddr = (y * pitch) + (x * bpp/8) + destBase;
    
    switch (bpp)
    {
        case 8:
            pixel = (unsigned long) readByte(pFB + destAddr);
            break;

        case 16:
            pixel = (unsigned long) readWord(pFB + destAddr);
            break;

        case 32:
        default:
            pixel = (unsigned long) readDWord(pFB + destAddr);
            break;
    }

    return(pixel);
}

static Bool
SMI_PrepareSolid(PixmapPtr pPixmap, int alu, Pixel planemask, Pixel fg)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    int dst_pitch;
    uint32_t dst_offset;
    Pixel pMask;

    ENTER();
    //DEBUG("alu=%02X, planemask=[%x]\n", alu, planemask);

	/* Bit Mask not supported > 16 bpp */
    if ((pPixmap->drawable.bitsPerPixel > 16) && 
	(!EXA_PM_IS_SOLID(&pPixmap->drawable, planemask)))
		LEAVE(FALSE);

	pSmi->dst_pitch = exaGetPixmapPitch(pPixmap) / (pPixmap->drawable.bitsPerPixel >> 3);
	pSmi->dst_offset = exaGetPixmapOffset(pPixmap) + pSmi->FBOffset;
    //DEBUG("pSmi->dst_pitch=%x, pSmi->dst_offset=%x\n", pSmi->dst_pitch, pSmi->dst_offset);
	

#if 0

	pSmi->exa_dbpp = pPixmap->drawable.bitsPerPixel>>3;
	pSmi->rop_alu = alu;
	pSmi->fg = fg;

#else
	pSmi->AccelCmd = FIELD_VALUE(0, DE_CONTROL, ROP, SMI_SolidRop[alu]) |
					FIELD_SET(0, DE_CONTROL, ROP_SELECT, ROP3) |
					FIELD_SET(0, DE_CONTROL, COMMAND, BITBLT) |
					FIELD_SET(0, DE_CONTROL, QUICK_START, ENABLE);

	/* Bit Mask (planemask) - 16 bit only */
	if (pPixmap->drawable.bitsPerPixel == 16) {
		pMask = planemask | 0xFFFF0000;
	} else {
		pMask = planemask | 0xFFFFFFFF;
	}
	
	deWaitForNotBusy();

	/* Destination Window Width */
    //WRITE_DPR(pSmi, 0x3C, (dst_pitch << 16) | (dst_pitch & 0xFFFF));
    WRITE_DPR(pSmi->pHardware, DE_WINDOW_WIDTH&0xff, 
                FIELD_VALUE(0, DE_WINDOW_WIDTH, DESTINATION, pSmi->dst_pitch) |
                FIELD_VALUE(0, DE_WINDOW_WIDTH, SOURCE, pSmi->dst_pitch));
    /* Destination Row Pitch */
    //WRITE_DPR(pSmi->pHardware, 0x10, (dst_pitch << 16) | (dst_pitch & 0xFFFF));
    WRITE_DPR(pSmi->pHardware, DE_PITCH&0xff, 
                FIELD_VALUE(0, DE_PITCH, DESTINATION, pSmi->dst_pitch) |
                FIELD_VALUE(0, DE_PITCH, SOURCE, pSmi->dst_pitch));

    WRITE_DPR(pSmi->pHardware, DE_MASKS&0xff, pMask); 

    /* Drawing engine data format */
    //WRITE_DPR(pSmi, 0x1C, PIXMAP_FORMAT(pPixmap));
    //DEBUG("pPixmap->drawable.bitsPerPixel = %d\n", pPixmap->drawable.bitsPerPixel);
    deSetPixelFormat(pPixmap->drawable.bitsPerPixel);
    /* Source and Destination Base Address (offset) */
    //WRITE_DPR(pSmi->pHardware, 0x40, dst_offset);
    //WRITE_DPR(pSmi, 0x44, dst_offset);
    WRITE_DPR(pSmi->pHardware, DE_WINDOW_SOURCE_BASE&0xff,
                FIELD_SET(0, DE_WINDOW_SOURCE_BASE, EXT, LOCAL) |
                FIELD_SET(0, DE_WINDOW_SOURCE_BASE, CS, 0) |
                FIELD_VALUE(0, DE_WINDOW_SOURCE_BASE, ADDRESS, pSmi->dst_offset)); 
    WRITE_DPR(pSmi->pHardware, DE_WINDOW_DESTINATION_BASE&0xff,
                FIELD_SET(0, DE_WINDOW_DESTINATION_BASE, EXT, LOCAL) |
                FIELD_SET(0, DE_WINDOW_DESTINATION_BASE, CS, 0) |
                FIELD_VALUE(0, DE_WINDOW_DESTINATION_BASE, ADDRESS, 
                                pSmi->dst_offset)); 

    /* Foreground Color */
    //WRITE_DPR(pSmi, 0x14, fg);
		
    WRITE_DPR(pSmi->pHardware, DE_FOREGROUND&0xff,
                FIELD_VALUE(0, DE_FOREGROUND, COLOR, fg));
    /* Mono Pattern High and Low */
    //WRITE_DPR(pSmi, 0x34, 0xFFFFFFFF);
    //WRITE_DPR(pSmi, 0x38, 0xFFFFFFFF);
    WRITE_DPR(pSmi->pHardware, DE_MONO_PATTERN_LOW&0xff, 0xFFFFFFFF);
    WRITE_DPR(pSmi->pHardware, DE_MONO_PATTERN_HIGH&0xff, 0xFFFFFFFF);

    //WRITE_DPR(pSmi, 0x0C, pSmi->AccelCmd);
    WRITE_DPR(pSmi->pHardware, DE_CONTROL&0xff, pSmi->AccelCmd);

#endif
	//return TRUE;
	LEAVE(TRUE);
}


static void
SMI_Solid(PixmapPtr pPixmap, int x1, int y1, int x2, int y2)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    int w, h;
	unsigned long destBase; /* Base address of destination surface counted from beginning of video frame buffer */
	unsigned long pitch;	/* Pitch value of destination surface in BYTES */
	unsigned long bpp;		/* Color depth of destination surface: 8, 16 or 32 */
	unsigned long color;	/* Fill color */
	unsigned long rop2; 	/* ROP value */
	unsigned long dx, dy;


    ENTER();
    //DEBUG("x1=%d y1=%d x2=%d y2=%d\n", x1, y1, x2, y2);
	//if(pSmi->rop_alu != 3)
    //DEBUG("pFB=[%x],rop2!=[%d]\n", pSmi->pFB,pSmi->rop_alu);
	//xf86Msg(X_INFO, "x1=%d y1=%d x2=%d y2=%d\n", x1, y1, x2, y2);
	//if(pSmi->exa_dbpp!=2)
	//DEBUG("use new bpp:[%d]bit~\n", pSmi->exa_dbpp);

	destBase = pSmi->dst_offset;
	pitch = pSmi->dst_pitch * pSmi->exa_dbpp;
	bpp = pSmi->exa_dbpp << 3;
	rop2 = pSmi->rop_alu;// shall we need some change?
	color = pSmi->fg;

#if 1
    w = (x2 - x1);
    h = (y2 - y1);

    if (pPixmap->drawable.bitsPerPixel == 24) 
	{
		x1 *= 3;
		w  *= 3;
    }

    //WaitQueue();
    deWaitForNotBusy();

    //WRITE_DPR(pSmi, 0x04, (x1 << 16) | (y1 & 0xFFFF));
    //WRITE_DPR(pSmi, 0x08, (w  << 16) | (h  & 0xFFFF));
    WRITE_DPR(pSmi->pHardware, DE_DESTINATION&0xff,
                FIELD_SET(0, DE_DESTINATION, WRAP, DISABLE) |
                FIELD_VALUE(0, DE_DESTINATION, X, x1) |
                FIELD_VALUE(0, DE_DESTINATION, Y, y1));
    WRITE_DPR(pSmi->pHardware, DE_DIMENSION&0xff,
                FIELD_VALUE(0, DE_DIMENSION, X, w) |
                FIELD_VALUE(0, DE_DIMENSION, Y_ET, h));

#else // sw solid
	if((rop2 == 0x3))//&&(bpp<=16))
		LEAVE();
	else
		DEBUG("rop2=[%d]\n", rop2);
	
	for (dy=y1; dy<(y2); dy++)
	{	
		for (dx=x1; dx<(x2); dx++)
		{
			
			SMI_swSetPixel(pSmi->pFB, destBase, pitch, bpp, dx, dy, color, rop2);
		}
	}
#endif

	LEAVE();


}

static void
SMI_DoneSolid(PixmapPtr pPixmap)
{
    ENTER();
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    deWaitForNotBusy();
    WRITE_DPR(pSmi->pHardware, DE_CONTROL&0xff, 0);
    LEAVE();
}




static Bool
SMI_PrepareCopy(PixmapPtr pSrcPixmap, PixmapPtr pDstPixmap, int xdir, int ydir,
		int alu, Pixel planemask)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    //int src_pitch, dst_pitch;
    unsigned long nDirection, de_ctrl, bytePerPixel;
    long opSign;
    Pixel pMask;
    
	ENTER();
	//DEBUG("planemask=[%x]\n", planemask);

    nDirection = LEFT_TO_RIGHT;
    opSign = 1;    /* Direction of ROP2 operation: 1 = Left to Right, (-1) = Right to Left */
    //bytePerPixel = bpp/8;
    //de_ctrl = 0;
    /*DEBUG("pSrcPixmap->(%d, %d), pDstPixmap->(%d, %d)\n", pSrcPixmap->drawable.width, pSrcPixmap->drawable.height,
        pDstPixmap->drawable.width, pDstPixmap->drawable.height);*/
    /* If source and destination are the same surface, need to check for overlay cases */
    //if (sBase == dBase && sPitch == dPitch)//ilena: donot need it now?
    {
        /* Determine direction of operation */
        if (ydir < 0)
        {
   
            nDirection = BOTTOM_TO_TOP;
        }
        else if (ydir >= 0)
        {
    
            nDirection = TOP_TO_BOTTOM;
        }
        else
        {
            /* sy == dy */
    
            if (xdir<=0)
            {    
                nDirection = RIGHT_TO_LEFT;
            }
            else
            {

                nDirection = LEFT_TO_RIGHT;
            }
        }
    }
	pSmi->direction = nDirection;
    /* calculate pitch in pixel unit */
    pSmi->src_pitch  = exaGetPixmapPitch(pSrcPixmap) / (pSrcPixmap->drawable.bitsPerPixel >> 3);
    pSmi->dst_pitch  = exaGetPixmapPitch(pDstPixmap) / (pDstPixmap->drawable.bitsPerPixel >> 3);
    /* calculate offset in 8 byte (64 bit) unit */
    pSmi->src_offset = exaGetPixmapOffset(pSrcPixmap) + pSmi->FBOffset;
    pSmi->dst_offset = exaGetPixmapOffset(pDstPixmap) + pSmi->FBOffset;
    
    //DEBUG("pSrcPixmap[%x], pDstPixmap[%x]\n", pSmi->src_offset, pSmi->dst_offset);
#if 0 // sw part
	if(pSrcPixmap->drawable.bitsPerPixel!=pDstPixmap->drawable.bitsPerPixel)
		{
			ERROR("error bpp while using exa.");
		}
	pSmi->exa_sbpp = pSrcPixmap->drawable.bitsPerPixel>>3;
	pSmi->exa_dbpp = pDstPixmap->drawable.bitsPerPixel>>3;
	pSmi->rop_alu = alu;

	//return TRUE;
	LEAVE(TRUE);
#else //hw by ilena, need 2 set again....


    /* Bit Mask (planemask) - 16 bit only */
    if (pSrcPixmap->drawable.bitsPerPixel == 16) {
        pMask = planemask | 0xFFFF0000;
    } else {
        pMask = planemask | 0xFFFFFFFF;
    }

    pSmi->AccelCmd = FIELD_VALUE(0, DE_CONTROL, ROP, SMI_BltRop[alu]) |
                        FIELD_SET(0, DE_CONTROL, ROP_SELECT, ROP3) |
                        FIELD_SET(0, DE_CONTROL, COMMAND, BITBLT) |
                        FIELD_SET(0, DE_CONTROL, QUICK_START, ENABLE);

    if (xdir < 0 || (ydir < 0)) {
	//pSmi->AccelCmd |= SMI_RIGHT_TO_LEFT;
        pSmi->AccelCmd |= FIELD_SET(0, DE_CONTROL, DIRECTION, RIGHT_TO_LEFT);
    }
    else {
        pSmi->AccelCmd |= FIELD_SET(0, DE_CONTROL, DIRECTION, LEFT_TO_RIGHT);
    }
	
    deWaitForNotBusy();

   /* Destination and Source Window Widths */
   //WRITE_DPR(pSmi, 0x3C, (dst_pitch << 16) | (src_pitch & 0xFFFF));
   WRITE_DPR(pSmi->pHardware, DE_WINDOW_WIDTH&0xff, 
			   FIELD_VALUE(0, DE_WINDOW_WIDTH, DESTINATION, pSmi->dst_pitch) |
			   FIELD_VALUE(0, DE_WINDOW_WIDTH, SOURCE, pSmi->src_pitch));
   /* Destination and Source Row Pitch */
   //WRITE_DPR(pSmi, 0x10, (dst_pitch << 16) | (src_pitch & 0xFFFF));
   WRITE_DPR(pSmi->pHardware, DE_PITCH&0xff, 
			   FIELD_VALUE(0, DE_PITCH, DESTINATION, pSmi->dst_pitch) |
			   FIELD_VALUE(0, DE_PITCH, SOURCE, pSmi->src_pitch));
   
   WRITE_DPR(pSmi->pHardware, DE_MASKS&0xff, pMask); 
   
   /* Drawing engine data format */
   deSetPixelFormat(pDstPixmap->drawable.bitsPerPixel);
   /* Destination and Source Base Address (offset) */
   //WRITE_DPR(pSmi, 0x40, src_offset);
   //WRITE_DPR(pSmi, 0x44, dst_offset);
   WRITE_DPR(pSmi->pHardware, DE_WINDOW_SOURCE_BASE&0xff,
			   FIELD_SET(0, DE_WINDOW_SOURCE_BASE, EXT, LOCAL) |
			   FIELD_SET(0, DE_WINDOW_SOURCE_BASE, CS, 0) |
			   FIELD_VALUE(0, DE_WINDOW_SOURCE_BASE, ADDRESS, pSmi->src_offset)); 
   WRITE_DPR(pSmi->pHardware, DE_WINDOW_DESTINATION_BASE&0xff,
			   FIELD_SET(0, DE_WINDOW_DESTINATION_BASE, EXT, LOCAL) |
			   FIELD_SET(0, DE_WINDOW_DESTINATION_BASE, CS, 0) |
			   FIELD_VALUE(0, DE_WINDOW_DESTINATION_BASE, ADDRESS, 
							   pSmi->dst_offset)); 
   
   WRITE_DPR(pSmi->pHardware, DE_CONTROL&0xff, pSmi->AccelCmd);
   
    LEAVE(TRUE);
#endif

}

static void
SMI_Copy(PixmapPtr pDstPixmap, int srcX, int srcY, int dstX,
	 int dstY, int width, int height)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
#if 0 // for sw exa	
    unsigned long color, nDirection;
	unsigned short color16;
    long x, y, opSign;
    opSign = 1;
	unsigned long sBase;  /* Address of source: offset in frame buffer */
	unsigned long sPitch; /* Pitch value of source surface in BYTE */
	unsigned long sx;
	unsigned long sy;     /* Starting coordinate of source surface */
	unsigned long dBase;  /* Address of destination: offset in frame buffer */
	unsigned long dPitch; /* Pitch value of destination surface in BYTE */
	unsigned long sbpp, dbpp;  //bits per pixel. we need source bpp and dest bpp. /* color depth of destiination, source must have same bpp */
	unsigned long dx;
	unsigned long dy;     /* Starting coordinate of destination surface */
	//unsigned long width; 
	//unsigned long height; /* width and height of rectange in pixel value */
	unsigned long rop2;
	int flag_same_bpp; //if we use un-equal source/dest bpp, the flag will be FALSE.
#endif	

	ENTER();
	/*DEBUG("srcX=%d srcY=%d dstX=%d dstY=%d width=%d height=%d\n",
	    srcX, srcY, dstX, dstY, width, height);*/
	//DEBUG("src->(%d,%d), dst->(%d,%d), wxh=(%d, %d)\n", srcX, srcY, dstX, dstY, width, height);
	//DEBUG("s_pitch=[%x], d_pitch=[%x], soffset=[%x],doffset=[%x]\n",pSmi->src_pitch, pSmi->dst_pitch,pSmi->src_offset, pSmi->dst_offset);
		//if(pSmi->exa_sbpp!= pSmi->exa_dbpp)
    //DEBUG("sbpp=[%d], dbpp[%d], pFB=[%x]\n", pSmi->exa_sbpp, pSmi->exa_dbpp, pSmi->pFB);
#if 0 //for sw exa		
	sx = srcX;
	sy = srcY;
	sBase = pSmi->src_offset;
	dBase = pSmi->dst_offset;
	sPitch = pSmi->src_pitch *pSmi->exa_sbpp;
	dPitch = pSmi->dst_pitch *pSmi->exa_dbpp;
	sbpp = pSmi->exa_sbpp << 3;
	dbpp = pSmi->exa_dbpp << 3;
	dx = dstX;
	dy = dstY;
	rop2 = pSmi->rop_alu;// shall we need some change?
	if(sbpp == dbpp)//(pSmi->Bpp<<3))
		flag_same_bpp = TRUE;
	else
		flag_same_bpp = FALSE;
#endif	
	//x = 0;
	//y = 0;
	#if 1
    if ((pSmi->direction == BOTTOM_TO_TOP) || (pSmi->direction == RIGHT_TO_LEFT))
    {
		srcX += width  - 1;
		srcY += height - 1;
		dstX += width  - 1;
		dstY += height - 1;
        //opSign = (-1);
		DEBUG("opSign = -1\n");
    }
	#endif
	
    if (pDstPixmap->drawable.bitsPerPixel == 24) {
		srcX  *= 3;
		dstX  *= 3;
		width *= 3;
		if (pSmi->AccelCmd & SMI_RIGHT_TO_LEFT) {
		    srcX += 2;
		    dstX += 2;
		}
    }

#if 1 //hw copy

    
    deWaitForNotBusy();
	WRITE_DPR(pSmi->pHardware, DE_CONTROL&0xff, pSmi->AccelCmd);
	WRITE_DPR(pSmi->pHardware, DE_SOURCE&0xff, 
					FIELD_SET(0, DE_SOURCE, WRAP, DISABLE) |
					FIELD_VALUE(0, DE_SOURCE, X_K1, srcX) |
					FIELD_VALUE(0, DE_SOURCE, Y_K2, srcY));
		WRITE_DPR(pSmi->pHardware, DE_DESTINATION&0xff,
					FIELD_SET(0, DE_DESTINATION, WRAP, DISABLE) |
					FIELD_VALUE(0, DE_DESTINATION, X, dstX) |
					FIELD_VALUE(0, DE_DESTINATION, Y, dstY));
		WRITE_DPR(pSmi->pHardware, DE_DIMENSION&0xff,
					FIELD_VALUE(0, DE_DIMENSION, X, width) |
					FIELD_VALUE(0, DE_DIMENSION, Y_ET, height));

	
		LEAVE();

#else
	#if 0
	if(width==40)
	{
	//LEAVE();
	            
		for (y=0; y<height; y++)
	    {

	        for (x=0; x<width; x++)
	        {
	        	    	//if(x%4==0)
				    		{color = 0xff000000;}
						//else
							//color = SMI_swGetPixel(pSmi->pFB, sBase, sPitch, bpp, sx+(opSign*x), sy+(opSign*y));
	            SMI_swSetPixel(pSmi->pFB, dBase, dPitch, sbpp, dx+(opSign*x), dy+(opSign*y), color, rop2);
	        }
	    }
		LEAVE();

	}
	#endif

    for (y=0; y<height; y++)
    {
    	if((rop2 == 0x3)&&(flag_same_bpp))
    	{
    		//if(sPitch=dPitch)
    		//DEBUG("USE memcpy.\n");
    		memcpy(pSmi->pFB+dBase+(sy+opSign*y)*dPitch, pSmi->pFB+sBase+(sy+opSign*y)*sPitch, width*pSmi->exa_sbpp);
			//else if(sPitch<dPitch)
				//memcpy(pSmi->pFB+dBase+(sy+opSign*y)*sPitch, pSmi->pFB+sBase+(sy+opSign*y)*sPitch, width*pSmi->exa_sbpp);
    	}
		else //if((sbpp == 32)&&(dbpp == 16))
			{
			#if 0
			memset(pSmi->pFB+dBase+(sy+opSign*y)*sPitch, color, width*pSmi->exa_bpp);
			#else
			//DEBUG("rop2=[%d].sbpp=[%d], psmi->dbpp=[%d]\n", rop2, sbpp, pSmi->Bpp);
	        for (x=0; x<width; x++)
	        {
	            color = SMI_swGetPixel(pSmi->pFB, sBase, sPitch, sbpp, sx+(opSign*x), sy+(opSign*y));
				color16 = Change32to16(color);
	            SMI_swSetPixel(pSmi->pFB, dBase, dPitch, dbpp, dx+(opSign*x), dy+(opSign*y), color16, rop2);
	        }
			#endif
		}
    }

	LEAVE();
#endif	
}

static void
SMI_DoneCopy(PixmapPtr pDstPixmap)
{
    ENTER();
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    deWaitForNotBusy();

	WRITE_DPR(pSmi->pHardware, DE_CONTROL&0xff, 0);

    LEAVE();
}


void
swComposite(CARD8 op,
            PicturePtr pSrc,
            PicturePtr pMask,
            PicturePtr pDst,
            INT16 xSrc,
            INT16 ySrc,
            INT16 xMask,
            INT16 yMask, INT16 xDst, INT16 yDst, CARD16 width, CARD16 height)
{
    pixman_image_t *src, *mask, *dest;
    int src_xoff, src_yoff;
    int msk_xoff, msk_yoff;
    int dst_xoff, dst_yoff;

    miCompositeSourceValidate(pSrc);
    if (pMask)
        miCompositeSourceValidate(pMask);

    src = image_from_pict(pSrc, FALSE, &src_xoff, &src_yoff);
    mask = image_from_pict(pMask, FALSE, &msk_xoff, &msk_yoff);
    dest = image_from_pict(pDst, TRUE, &dst_xoff, &dst_yoff);
	dst_xoff = 0;
	dst_yoff = 0;

    if (src && dest && !(pMask && !mask)) {
        pixman_image_composite(op, src, mask, dest,
                               xSrc + src_xoff, ySrc + src_yoff,
                               xMask + msk_xoff, yMask + msk_yoff,
                               xDst + dst_xoff, yDst + dst_yoff, width, height);
    }

    free_pixman_pict(pSrc, src);
    free_pixman_pict(pMask, mask);
    free_pixman_pict(pDst, dest);
}
/**
 * Forces a real devPrivate.ptr for hidden pixmaps, so that we can call down to
 * fb functions.
 */
static void
smiPreparePipelinedAccess(PixmapPtr pPix, int index)
{
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    SmiExaPriv *swexa = pSmi->EXAPriv;

    assert(swexa->saved_ptrs[index] == NULL);
    swexa->saved_ptrs[index] = pPix->devPrivate.ptr;

    if (pPix->devPrivate.ptr != NULL)
        return;

    pPix->devPrivate.ptr = pSmi->EXADriverPtr->memoryBase + exaGetPixmapOffset(pPix);
}

/**
 * Restores the original devPrivate.ptr of the pixmap from before we messed with
 * it.
 */
static void
smiFinishPipelinedAccess(PixmapPtr pPix, int index)
{
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    SmiExaPriv *swexa = pSmi->EXAPriv;

    pPix->devPrivate.ptr = swexa->saved_ptrs[index];
    swexa->saved_ptrs[index] = NULL;
}

static Bool
SMI_CheckComposite(int op, PicturePtr pSrcPicture, PicturePtr pMaskPicture, PicturePtr pDstPicture)
{
    ENTER();
    /* Exercise the component alpha helper, so fail on this case like a normal
     * driver
     */
    if (pMaskPicture && pMaskPicture->componentAlpha && op == PictOpOver)
		LEAVE(FALSE);

    LEAVE(TRUE);
}

static Bool
SMI_PrepareComposite(int op, PicturePtr pSrcPicture, PicturePtr pMaskPicture, PicturePtr pDstPicture,
		       PixmapPtr pSrc, PixmapPtr pMask, PixmapPtr pDst)
{
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    SmiExaPriv *swexa = pSmi->EXAPriv;

    ENTER();
	if(!pSrc){
		DEBUG("Failed to create solid scratch pixmap\n");
		LEAVE(FALSE);
	}

    smiPreparePipelinedAccess(pDst, EXA_PREPARE_DEST);
    smiPreparePipelinedAccess(pSrc, EXA_PREPARE_SRC);
    if (pMask != NULL)
        smiPreparePipelinedAccess(pMask, EXA_PREPARE_MASK);

    swexa->op = op;
    swexa->pSrcPicture = pSrcPicture;
    swexa->pMaskPicture = pMaskPicture;
    swexa->pDstPicture = pDstPicture;
    swexa->pSrc = pSrc;
    swexa->pMask = pMask;
    swexa->pDst = pDst;

	LEAVE(TRUE);
}

static void
SMI_Composite(PixmapPtr pDst, int srcX, int srcY, int maskX, int maskY,
		int dstX, int dstY, int width, int height)
{
	ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
	SMIPtr pSmi = SMIPTR(pScrn);
    SmiExaPriv *swexa = pSmi->EXAPriv;

	ENTER();
	
    swComposite(swexa->op, swexa->pSrcPicture, swexa->pMaskPicture,
                swexa->pDstPicture, srcX, srcY, maskX, maskY, dstX, dstY,
                width, height);

	LEAVE();
}

static void
SMI_DoneComposite(PixmapPtr pDst)
{
	ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
	SMIPtr pSmi = SMIPTR(pScrn);
    SmiExaPriv *swexa = pSmi->EXAPriv;
    ENTER();

    if (swexa->pMask != NULL)
        smiFinishPipelinedAccess(swexa->pMask, EXA_PREPARE_MASK);
    smiFinishPipelinedAccess(swexa->pSrc, EXA_PREPARE_SRC);
    smiFinishPipelinedAccess(swexa->pDst, EXA_PREPARE_DEST);

	LEAVE();
}

Bool
SMI_UploadToScreen(PixmapPtr pDst, int x, int y, int w, int h,
		   char *src, int src_pitch)
{
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);
    int dst_pixelpitch, src_pixelpitch, align, aligned_pitch;
    uint32_t dst_offset;

    ENTER();
	    DEBUG("x=%d y=%d w=%d h=%d src=%d src_pitch=%d\n",
	  x, y, w, h, src, src_pitch);


    /* calculate pitch in pixel unit */
    dst_pixelpitch  = exaGetPixmapPitch(pDst) / (pDst->drawable.bitsPerPixel >> 3);
    src_pixelpitch = src_pitch / (pDst->drawable.bitsPerPixel >> 3);
    /* calculate offset in 8 byte (64 bit) unit */
    dst_offset = exaGetPixmapOffset(pDst);

    /* set clipping */
    SMI_SetClippingRectangle(pScrn, x, y, x+w, y+h);	

	deSystemMem2VideoMemBlt(src, src_pitch, dst_offset, exaGetPixmapPitch(pDst),
                                pDst->drawable.bitsPerPixel, x, y, w, h, 0xc);
    /* disable clipping */
    SMI_DisableClipping(pScrn);

    exaWaitSync(pDst->drawable.pScreen);
	LEAVE(TRUE);
}

Bool
SMI_DownloadFromScreen(PixmapPtr pSrc, int x, int y, int w, int h,
		       char *dst, int dst_pitch)
{
    unsigned char *src = pSrc->devPrivate.ptr;
    int src_pitch = exaGetPixmapPitch(pSrc);

    ENTER();
	
	LEAVE(TRUE);
}

Bool SMI_EXAInit(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    SMIPtr pSmi = SMIPTR(pScrn);

	ENTER();

	if (!(pSmi->EXAPriv = xcalloc(1, sizeof(SmiExaPriv)))) {\
		xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Failed to allocate fakeEXA.\n");
		pSmi->NoAccel = TRUE;
		LEAVE(FALSE);
	}
    if (!(pSmi->EXADriverPtr = exaDriverAlloc())) {
	xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Failed to allocate EXADriverRec.\n");
	free(pSmi->EXAPriv);
	pSmi->NoAccel = TRUE;
	LEAVE(FALSE);
    }
	
	/* Require 2.1 semantics:
	   Don't uninitialize the memory manager when swapping out */
	pSmi->EXADriverPtr->exa_major = 2;
#if EXA_VERSION_MINOR >= 2
	pSmi->EXADriverPtr->exa_minor = 2;
#else
	pSmi->EXADriverPtr->exa_minor = 1;
#endif

    /* Memory Manager */
    pSmi->EXADriverPtr->memoryBase = pSmi->pFB;
	pSmi->EXADriverPtr->offScreenBase = pScrn->virtualX * pScrn->virtualY *pSmi->Bpp;
    pSmi->EXADriverPtr->memorySize = pSmi->videoRAMBytes;
	DEBUG("vX=[%d], vY=[%d]\n", pScrn->virtualX, pScrn->virtualY );
    pSmi->EXADriverPtr->pixmapPitchAlign  = 16;//?
    pSmi->EXADriverPtr->pixmapOffsetAlign = 16;//?
    pSmi->EXADriverPtr->flags = EXA_OFFSCREEN_ALIGN_POT;//?

	pSmi->EXADriverPtr->flags |= EXA_TWO_BITBLT_DIRECTIONS;
    if (pSmi->EXADriverPtr->memorySize > pSmi->EXADriverPtr->offScreenBase) {
	/* Offscreen Pixmaps */
	pSmi->EXADriverPtr->flags |= EXA_OFFSCREEN_PIXMAPS;
	xf86DrvMsg(pScrn->scrnIndex, X_INFO,
		   "EXA offscreen memory manager enabled. \n");
    }
    else
	xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
		   "Not enough video RAM for EXA offscreen memory manager.\n");

	/* 12 bit coordinates */
    pSmi->EXADriverPtr->maxX = 4096;
    pSmi->EXADriverPtr->maxY = 4096;
    /* Solid */
    pSmi->EXADriverPtr->PrepareSolid = SMI_PrepareSolid;
    pSmi->EXADriverPtr->Solid = SMI_Solid;
    pSmi->EXADriverPtr->DoneSolid = SMI_DoneSolid;

    /* Copy */
    pSmi->EXADriverPtr->PrepareCopy = SMI_PrepareCopy;
    pSmi->EXADriverPtr->Copy = SMI_Copy;
    pSmi->EXADriverPtr->DoneCopy = SMI_DoneCopy;

    /* Composite */
    pSmi->EXADriverPtr->CheckComposite = SMI_CheckComposite;
    pSmi->EXADriverPtr->PrepareComposite = SMI_PrepareComposite;
	pSmi->EXADriverPtr->Composite = SMI_Composite;
    pSmi->EXADriverPtr->DoneComposite = SMI_DoneComposite;
    /* Sync */
    pSmi->EXADriverPtr->WaitMarker = SMI_EXASync;


    /* DFS & UTS */
    //pSmi->EXADriverPtr->UploadToScreen = SMI_UploadToScreen;
	//pSmi->EXADriverPtr->DownloadFromScreen = SMI_DownloadFromScreen;//?
	
    if(!exaDriverInit(pScreen, pSmi->EXADriverPtr)) {
	xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "exaDriverInit failed.\n");
	LEAVE(FALSE);
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "EXA Acceleration enabled. pFB=[%x]\n", pSmi->pFB);


	deInit();//???

            
    SMI_EngineReset(pScrn);


	LEAVE(TRUE);

}

#endif
